// WCAG colour maths, shared by the colour and contrast checks.

export const hex = ([r, g, b]) => '#' + [r, g, b].map((c) => Math.round(c).toString(16).padStart(2, '0')).join('');

export const describe = (rgba) => {
  if (!rgba) return 'unreadable colour';
  const a = Math.round(rgba[3] * 1000) / 1000;
  return a === 1 ? hex(rgba) : `${hex(rgba)} at alpha ${a}`;
};

const channel = (c) => {
  const s = c / 255;
  return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
};

export const luminance = ([r, g, b]) => 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);

export const contrast = (a, b) => {
  const [l1, l2] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (l1 + 0.05) / (l2 + 0.05);
};

// Composite a colour with alpha over an opaque background.
export const over = ([r, g, b, a], [br, bg, bb]) => [r * a + br * (1 - a), g * a + bg * (1 - a), b * a + bb * (1 - a)];

// WCAG large text: at least 18pt (24px), or 14pt (18.66px) and bold.
export const contrastThreshold = (fontSizePx, fontWeight) => (fontSizePx >= 24 || (fontSizePx >= 18.66 && fontWeight >= 700) ? 3 : 4.5);
