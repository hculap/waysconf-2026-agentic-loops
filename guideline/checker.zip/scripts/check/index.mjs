// Checks the rendered page against design/data. No language model, no questions, same answer twice.
// Run with: npm run check                 (builds the site, serves dist/, checks it)
//           npm run check -- --url <URL>  (checks that address instead)
// Exit code: 0 all checks pass, 1 a check failed, 2 a check could not run.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadDesign } from './design.mjs';
import { serve } from './serve.mjs';
import { launch, openPage, VIEWPORT_HEIGHT } from './browser.mjs';
import { render, statusOf } from './report.mjs';
import { runBuild, judgeBuild } from './checks/build.mjs';
import * as consoleCheck from './checks/console.mjs';
import * as sectionsCheck from './checks/sections.mjs';
import * as a11yCheck from './checks/a11y.mjs';
import * as coloursCheck from './checks/colours.mjs';
import * as copyCheck from './checks/copy.mjs';
import * as overflowCheck from './checks/overflow.mjs';
import * as imagesCheck from './checks/images.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const REPORT = path.join(ROOT, 'check-report.md');

const newCheck = (id, title, how) => ({ id, title, how, failures: [], notRun: [], count: 0 });
const checks = {
  build: newCheck(1, 'Project builds with no errors', 'Runs astro build; fails on a non-zero exit code or any error line in its output.'),
  console: newCheck(2, 'No browser console errors on load', 'Loads the page at every design width and records console errors, uncaught exceptions, failed requests and HTTP ≥ 400 responses.'),
  sections: newCheck(3, 'Design sections present and in order', 'Selectors come from each section\'s notes in design/data/sections.json; each must match one rendered element, in orderByWidth order by DOM position and by rendered top edge.'),
  a11y: newCheck(4, 'Accessible at every design width', `axe-core (${a11yCheck.AXE_TAGS.join(', ')}) at every design width. Violations fail. Incomplete colour-contrast results are measured from rendered pixels (lowest ratio under the glyphs); any other incomplete result fails.`),
  colours: newCheck(5, 'Only design colours are painted', 'Every computed colour of every rendered element and pseudo-element (text, backgrounds, gradients, borders, outlines, decorations, shadows, SVG fill/stroke, SVG images, page canvas, keyboard-focus states) must be a design/data/colours.json token at an alpha the design uses.'),
  copy: newCheck(6, 'All design copy appears on the page', 'Every text entry in design/data/copy.json must be in its section\'s rendered text at each width it is drawn at (visually hidden entries only need to be in the DOM); open-menu copy is checked after pressing the menu button.'),
  overflow: newCheck(7, 'No sideways overflow at the narrowest width', 'At the narrowest design width: the document must not be wider than the viewport, and no rendered element may extend past either side unless a container inside the viewport clips it.'),
  images: newCheck(8, 'Every image has real alt text', 'Every img, input[type=image] and [role=img] needs non-empty alt text that is not its file name; every photo design/data/images.json places on the page must be rendered with its design alt text.'),
};
const browserChecks = [
  [checks.console, consoleCheck, 'all'],
  [checks.sections, sectionsCheck, 'all'],
  [checks.images, imagesCheck, 'all'],
  [checks.overflow, overflowCheck, 'narrowest'],
  [checks.a11y, a11yCheck, 'all'],
  [checks.colours, coloursCheck, 'all'],
  [checks.copy, copyCheck, 'all'], // last: it opens the menu
];

function parseArgs(argv) {
  let url = null;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--url') {
      url = argv[++i];
      if (!url) throw new Error('--url needs an address, e.g. --url https://example.com/');
    } else if (a.startsWith('--url=')) url = a.slice(6);
    else throw new Error(`unknown argument "${a}". Usage: npm run check [-- --url <address>]`);
  }
  if (url) {
    let u;
    try {
      u = new URL(url);
    } catch {
      throw new Error(`--url "${url}" is not a valid address`);
    }
    if (!['http:', 'https:'].includes(u.protocol)) throw new Error(`--url must be http or https, got ${u.protocol}`);
  }
  return { url };
}

async function main() {
  const notes = [];
  let target = 'built site (dist/), served locally by the checker';
  let args;
  try {
    args = parseArgs(process.argv.slice(2));
  } catch (err) {
    for (const c of Object.values(checks)) c.notRun.push(`checker arguments are invalid: ${err.message}`);
    return finish({ target: '(none: invalid arguments)', widths: [], notes });
  }
  if (args.url) target = args.url;

  let design = null;
  try {
    design = loadDesign(ROOT);
    notes.push(`Design widths: ${design.widths.join(', ')}; narrowest ${design.narrowest}. Viewport height ${VIEWPORT_HEIGHT}px, device scale 1.`);
    notes.push(`Design colours (design/data/colours.json, with alpha levels the design paints them at): ${coloursCheck.allowedList(design.colours)}.`);
  } catch (err) {
    for (const [c] of browserChecks) c.notRun.push(`design/data could not be read: ${err.message}`);
  }

  // 1. Build (always, in both modes).
  const build = await runBuild(ROOT);
  judgeBuild(build, checks.build);

  if (!design) return finish({ target, widths: [], notes });

  // Where is the page?
  let server = null;
  let url = args.url;
  const cannot = (reason) => {
    for (const [c] of browserChecks) c.notRun.push(reason);
  };
  if (!url) {
    const index = path.join(ROOT, 'dist', 'index.html');
    if (statusOf(checks.build) !== 'PASS') return cannot('the page could not be served because the build did not succeed'), finish({ target, widths: design.widths, notes });
    if (!fs.existsSync(index)) return cannot('the build produced no dist/index.html, so there is no page to load'), finish({ target, widths: design.widths, notes });
    try {
      server = await serve(path.join(ROOT, 'dist'));
      url = server.url;
    } catch (err) {
      return cannot(`the local server for dist/ could not start: ${err.message}`), finish({ target, widths: design.widths, notes });
    }
  }

  let browser;
  try {
    browser = await launch();
  } catch (err) {
    await server?.close();
    return cannot(`the browser did not start: ${err.message.split('\n')[0]}`), finish({ target, widths: design.widths, notes });
  }

  try {
    for (const width of design.widths) {
      let opened;
      try {
        opened = await openPage(browser, url, width);
      } catch (err) {
        for (const [c, , when] of browserChecks) if (when === 'all' || width === design.narrowest) c.notRun.push(err.message);
        continue;
      }
      for (const [c, mod, when] of browserChecks) {
        if (when === 'narrowest' && width !== design.narrowest) continue;
        try {
          await mod.run({ ...opened, width, design, check: c });
        } catch (err) {
          c.notRun.push(`${width}px: the check crashed: ${err.message.split('\n')[0]}`);
        }
      }
      await opened.context.close();
    }
  } finally {
    await browser.close();
    await server?.close();
  }
  for (const [c, mod] of browserChecks) {
    mod.finalize?.(c);
    c.failures = mergeWidths(c.failures);
    if (c.count === 0 && !c.notRun.length && !c.failures.length)c.notRun.push('the check evaluated nothing');
  }
  return finish({ target, widths: design.widths, notes });
}

// The same failure at several widths becomes one entry listing the widths.
function mergeWidths(failures) {
  const merged = new Map();
  for (const f of failures) {
    const m = /^(\d+)px( · [\s\S]*)?$/.exec(f.where);
    if (!m) {
      merged.set(Symbol(), f);
      continue;
    }
    const key = JSON.stringify([f.what, m[2] || '', f.expected, f.actual]);
    if (!merged.has(key)) merged.set(key, { ...f, widths: [], rest: m[2] || '' });
    merged.get(key).widths.push(+m[1]);
  }
  return [...merged.values()].map(({ widths, rest, ...f }) => (widths ? { ...f, where: `${widths.map((w) => `${w}px`).join(', ')}${rest}` } : f));
}

function finish({ target, widths, notes }) {
  const list = Object.values(checks).sort((a, b) => a.id - b.id);
  const exitCode = list.some((c) => c.notRun.length) ? 2 : list.some((c) => c.failures.length) ? 1 : 0;
  const text = render({ target, widths, checks: list, notes, exitCode });
  fs.writeFileSync(REPORT, text + '\n');
  process.stdout.write(text + '\n');
  const summary = list.map((c) => `${c.id}. ${c.title}: ${statusOf(c)}`).join('\n');
  process.stdout.write(`\n${summary}\n\nReport written to ${path.relative(process.cwd(), REPORT) || REPORT}\nExit code ${exitCode}\n`);
  process.exitCode = exitCode;
}

main().catch((err) => {
  for (const c of Object.values(checks)) c.notRun.push(`the checker crashed: ${err.stack || err}`);
  finish({ target: '(checker crashed)', widths: [], notes: [] });
});
