// Renders check results as Markdown, for the terminal and for check-report.md.

export const statusOf = (c) => (c.notRun.length ? 'NOT RUN' : c.failures.length ? 'FAIL' : 'PASS');

const block = (s) => {
  const text = String(s);
  return text.includes('\n') ? '\n\n```\n' + text + '\n```\n' : ` ${text}`;
};

export function render({ target, widths, checks, notes, exitCode }) {
  const out = [];
  out.push('# Design check report', '');
  out.push(`- Target: ${target}`);
  out.push(`- Widths checked: ${widths.length ? widths.map((w) => `${w}px`).join(', ') : '(none — design/data unavailable)'}`);
  out.push(`- Result: **${exitCode === 0 ? 'PASS' : 'FAIL'}** (exit code ${exitCode})`, '');
  out.push('| # | Check | Status | Items checked | Failures |', '|---|---|---|---|---|');
  for (const c of checks) out.push(`| ${c.id} | ${c.title} | ${statusOf(c) === 'PASS' ? 'PASS' : `**${statusOf(c)}**`} | ${c.count} | ${c.failures.length} |`);
  out.push('');
  if (notes.length) {
    out.push('## Notes', '');
    for (const n of notes) out.push(`- ${n}`);
    out.push('');
  }
  for (const c of checks) {
    const status = statusOf(c);
    out.push(`## ${c.id}. ${c.title} — ${status}`, '');
    out.push(`_${c.how}_`, '');
    if (status === 'PASS') {
      out.push(`Passed: ${c.count} item(s) checked, 0 failures.`, '');
      continue;
    }
    if (c.notRun.length) {
      out.push('**This check did not run, which counts as a failure:**', '');
      for (const r of c.notRun) out.push(`- ${r}`);
      out.push('');
    }
    c.failures.forEach((f, i) => {
      out.push(`### ${c.id}.${i + 1} ${f.what}`, '');
      out.push(`- **What failed:** ${f.what}`);
      out.push(`- **Where:**${block(f.where)}`);
      out.push(`- **Design says:**${block(f.expected)}`);
      out.push(`- **Actually:**${block(f.actual)}`);
      out.push('');
    });
  }
  return out.join('\n');
}
