// Check 4: accessibility at every design width (axe-core), with incomplete contrast results
// measured from the rendered pixels.
import { AxeBuilder } from '@axe-core/playwright';
import { PNG } from 'pngjs';
import { contrast, contrastThreshold, describe, hex, over } from '../colour.mjs';

export const AXE_TAGS = ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa', 'best-practice'];

const targetOf = (node) => (node.target || []).map((t) => (Array.isArray(t) ? t.join(' >>> ') : t)).join(' ');

const contrastData = (node) => {
  const d = [...(node.any || []), ...(node.all || []), ...(node.none || [])].find((c) => c.id === 'color-contrast')?.data;
  if (!d) return null;
  return d;
};

export async function run({ page, width, check }) {
  const results = await new AxeBuilder({ page }).withTags(AXE_TAGS).analyze();
  check.count += results.passes.length + results.violations.length + results.incomplete.length;

  for (const rule of results.violations) {
    for (const node of rule.nodes) {
      const d = rule.id === 'color-contrast' ? contrastData(node) : null;
      check.failures.push({
        what: `axe ${rule.id} (${rule.impact}): ${rule.help}`,
        where: `${width}px · ${targetOf(node)} · ${node.html.slice(0, 160)}`,
        expected: d
          ? `contrast ≥ ${d.expectedContrastRatio} (WCAG AA; ${rule.helpUrl})`
          : `no ${rule.id} violation (WCAG AA / best practice; ${rule.helpUrl})`,
        actual: d
          ? `contrast ${d.contrastRatio}:1 — text ${d.fgColor} on ${d.bgColor}, ${d.fontSize} ${d.fontWeight}`
          : node.failureSummary.replace(/\s*\n\s*/g, ' '),
      });
    }
  }

  for (const rule of results.incomplete) {
    for (const node of rule.nodes) {
      if (rule.id === 'color-contrast') {
        await measureContrast(page, width, node, check);
      } else {
        check.failures.push({
          what: `axe ${rule.id} could not be verified automatically (incomplete is not a pass): ${rule.help}`,
          where: `${width}px · ${targetOf(node)} · ${node.html.slice(0, 160)}`,
          expected: `a definite pass for ${rule.id} (${rule.helpUrl})`,
          actual: `axe marked it incomplete: ${(node.failureSummary || [...node.any, ...node.all, ...node.none].map((c) => c.message).join('; ')).replace(/\s*\n\s*/g, ' ')}`,
        });
      }
    }
  }
}

async function measureContrast(page, width, node, check) {
  const target = targetOf(node);
  const axeReason = [...node.any, ...node.all, ...node.none].map((c) => c.message).join('; ');
  const d = contrastData(node);
  const fail = (actual, extra = {}) =>
    check.failures.push({
      what: `text contrast measured from rendered pixels is too low or could not be measured (axe: incomplete — ${axeReason})`,
      where: `${width}px · ${target}${extra.where ? ` · ${extra.where}` : ''}`,
      expected: extra.expected || 'contrast ≥ 4.5:1 (≥ 3:1 for large text), WCAG AA 1.4.3',
      actual,
    });
  if (!target || (node.target || []).some(Array.isArray)) return fail('cannot be measured: element is inside a shadow root or frame');

  const clip = await page.evaluate((sel) => window.__chk.prepareForShot(sel), target);
  if (!clip) return fail('cannot be measured: element not found for screenshot');
  if (clip.width <= 0 || clip.height <= 0) return fail(`cannot be measured: element has no visible area in the viewport (${clip.width}×${clip.height})`);
  const shot = async () => PNG.sync.read(await page.screenshot({ clip: { x: clip.x, y: clip.y, width: clip.width, height: clip.height }, animations: 'disabled', caret: 'hide', scale: 'css' }));

  const withText = await shot();
  const info = await page.evaluate((sel) => window.__chk.hideOwnText(sel), target);
  let without;
  try {
    without = await shot();
  } finally {
    await page.evaluate((sel) => window.__chk.restoreText(sel), target);
  }
  if (!info) return fail('cannot be measured: element not found when hiding its text');
  const threshold = d?.expectedContrastRatio ? parseFloat(d.expectedContrastRatio) : contrastThreshold(info.fontSize, info.fontWeight);
  const expected = `contrast ≥ ${threshold}:1 (WCAG AA 1.4.3; text ${info.fontSize}px weight ${info.fontWeight})`;
  const whereText = `${info.where.path} "${info.where.text}"`;
  if (!info.color || info.color[3] * info.opacity <= 0) return fail(`cannot be measured: the text colour is ${info.colorValue} (transparent or unreadable)`, { expected, where: whereText });

  const fg = [info.color[0], info.color[1], info.color[2], info.color[3] * info.opacity];
  let min = Infinity;
  let at = null;
  let glyphPixels = 0;
  const { width: w, height: h } = withText;
  if (without.width !== w || without.height !== h) return fail('cannot be measured: screenshots differ in size', { expected, where: whereText });
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const a = withText.data;
      const b = without.data;
      if (a[i] === b[i] && a[i + 1] === b[i + 1] && a[i + 2] === b[i + 2]) continue;
      glyphPixels++;
      const bg = [b[i], b[i + 1], b[i + 2]];
      const ratio = contrast(over(fg, bg), bg);
      if (ratio < min) {
        min = ratio;
        at = { x: clip.x + clip.scrollX + x, y: clip.y + clip.scrollY + y, bg };
      }
    }
  }
  check.count++;
  if (glyphPixels === 0) return fail('cannot be measured: hiding the text changed no pixels (no glyphs found in the viewport)', { expected, where: whereText });
  if (min < threshold) {
    fail(
      `lowest measured contrast ${min.toFixed(3)}:1 — text ${describe(fg)} over background pixel ${hex(at.bg)} at page x ${at.x}, y ${at.y} (${glyphPixels} glyph pixels measured)`,
      { expected, where: whereText },
    );
  }
}
