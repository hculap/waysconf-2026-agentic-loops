// Check 3: every section the design defines is present, once, rendered, and in the design's order.
export async function run({ page, width, design, check }) {
  const expected = design.sections[width];
  const found = await page.evaluate((exp) => window.__chk.sections(exp), expected.map(({ name, selector }) => ({ name, selector })));
  const inventory = await page.evaluate(() => window.__chk.landmarkInventory());
  const actuallyThere = inventory.length ? `the page has: ${inventory.join('; ')}` : 'the page has no section, landmark or [data-section] elements';
  const good = [];
  for (const [i, s] of found.entries()) {
    check.count++;
    const source = expected[i].source;
    if (s.error) {
      check.failures.push({ what: `${s.name}: selector could not be evaluated`, where: `${width}px`, expected: `${s.selector} (${source})`, actual: s.error });
    } else if (s.count === 0) {
      check.failures.push({ what: `${s.name} is missing`, where: `${width}px · position ${i + 1} of ${expected.length}`, expected: `exactly one element matching ${s.selector} (${source})`, actual: `no element matches; ${actuallyThere}` });
    } else if (s.count > 1) {
      check.failures.push({ what: `${s.name} appears ${s.count} times`, where: `${width}px · ${s.found.map((f) => f.path).join(' | ')}`, expected: `exactly one element matching ${s.selector}`, actual: `${s.count} elements match` });
    } else if (!s.found[0].visible) {
      check.failures.push({ what: `${s.name} is present but not rendered`, where: `${width}px · ${s.found[0].path}`, expected: `${s.selector} rendered with a non-zero box`, actual: `hidden or zero-sized (top ${s.found[0].top}, height ${s.found[0].height})` });
    } else {
      good.push({ ...s, designIndex: i });
    }
  }
  if (good.length < 2) return;
  check.count++;
  const designOrder = good.map((s) => s.name);
  const byDom = [...good].sort((a, b) => a.domIndex - b.domIndex).map((s) => s.name);
  const byTop = [...good].sort((a, b) => a.found[0].top - b.found[0].top || a.domIndex - b.domIndex).map((s) => s.name);
  if (byDom.join() !== designOrder.join()) {
    check.failures.push({ what: 'sections are out of order in the document', where: `${width}px`, expected: designOrder.join(' → ') + ` (design/data/sections.json › orderByWidth[${width}])`, actual: byDom.join(' → ') });
  }
  if (byTop.join() !== designOrder.join()) {
    check.failures.push({
      what: 'sections are out of order on screen (by rendered top edge)',
      where: `${width}px`,
      expected: designOrder.join(' → ') + ` (design/data/sections.json › orderByWidth[${width}])`,
      actual: [...good].sort((a, b) => a.found[0].top - b.found[0].top).map((s) => `${s.name} (top ${s.found[0].top})`).join(' → '),
    });
  }
}
