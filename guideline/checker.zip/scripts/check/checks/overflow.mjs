// Check 7: nothing overflows sideways at the narrowest design width.
export async function run({ page, width, check }) {
  const r = await page.evaluate(() => window.__chk.overflow());
  check.count++;
  if (r.scrollWidth > r.clientWidth || r.bodyScrollWidth > r.clientWidth) {
    check.failures.push({
      what: 'the page scrolls sideways',
      where: `${width}px · document`,
      expected: `document width ≤ ${width}px (design/data/sections.json › widths, narrowest)`,
      actual: `documentElement.scrollWidth ${r.scrollWidth}px, body.scrollWidth ${r.bodyScrollWidth}px, viewport ${r.clientWidth}px`,
    });
  }
  for (const o of r.offenders) {
    check.count++;
    check.failures.push({
      what: 'element extends past the side of the viewport and is not clipped by a container',
      where: `${width}px · ${o.path} · ${o.section} · ${o.box}${o.text ? ` · "${o.text}"` : ''}`,
      expected: `left edge ≥ 0 and right edge ≤ ${r.clientWidth}px`,
      actual: `left ${o.left}px, right ${o.right}px`,
    });
  }
}
