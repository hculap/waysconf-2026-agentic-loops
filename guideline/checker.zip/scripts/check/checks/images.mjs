// Check 8: every image has alt text that is not a file name, and every design photo is on the page with its design alt.
const EXT = /\.(jpe?g|png|webp|avif|gif|svg|bmp|tiff?)$/i;
const norm = (s) => s.replace(/\s+/g, ' ').trim();
const loose = (s) => norm(s.toLowerCase().replace(/[-_]+/g, ' '));

function fileNameForms(src, designNames) {
  const forms = new Set();
  const add = (s) => {
    if (!s) return;
    forms.add(s.toLowerCase());
    forms.add(loose(s));
  };
  let base = '';
  try {
    base = decodeURIComponent(new URL(src, 'http://x/').pathname.split('/').pop() || '');
  } catch {
    base = src.split('/').pop() || '';
  }
  const stem = base.replace(EXT, '');
  add(base);
  add(stem);
  add(stem.replace(/\.[A-Za-z0-9_-]{6,}$/, '')); // Astro/Vite hashed names: name.HASH.ext
  add(stem.replace(/_[A-Za-z0-9]{6,}$/, ''));
  for (const n of designNames) {
    add(n);
    add(n.replace(EXT, ''));
  }
  forms.delete('');
  return forms;
}

export async function run({ page, width, design, check }) {
  const imgs = await page.evaluate(() => window.__chk.images());
  const designNames = design.images.fileNames;

  for (const img of imgs) {
    check.count++;
    const where = `${width}px · ${img.path} · ${img.section} · ${img.box} · src ${img.src || '(none)'}`;
    if (img.alt === null) {
      check.failures.push({ what: `<${img.tag}> has no alt text`, where, expected: 'an alt attribute (or accessible name) describing the image', actual: 'no alt attribute' });
      continue;
    }
    if (!norm(img.alt)) {
      check.failures.push({ what: `<${img.tag}> has empty alt text`, where, expected: 'non-empty alt text describing the image', actual: `alt="${img.alt}"` });
      continue;
    }
    const forms = fileNameForms(img.src, designNames);
    if (forms.has(img.alt.trim().toLowerCase()) || forms.has(loose(img.alt)) || EXT.test(img.alt.trim())) {
      check.failures.push({ what: `<${img.tag}> alt text is a file name`, where, expected: 'alt text describing the image, not its file name', actual: `alt="${img.alt}"` });
    }
  }

  for (const d of design.images.onPage) {
    if (!d.widths.includes(width)) continue;
    check.count++;
    const match = imgs.find((i) => i.visible && i.alt !== null && norm(i.alt) === norm(d.alt));
    if (match) continue;
    const hidden = imgs.find((i) => i.alt !== null && norm(i.alt) === norm(d.alt));
    const keys = [d.hash, ...d.exportNames.map((n) => n.replace(EXT, ''))].map((s) => s.toLowerCase());
    const bySrc = imgs.find((i) => keys.some((k) => i.src.toLowerCase().includes(k)));
    let actual;
    if (hidden) actual = `an image with this alt exists but is not rendered at ${width}px (${hidden.path})`;
    else if (bySrc) actual = `the photo is used by ${bySrc.path} with alt ${bySrc.alt === null ? '(missing)' : `"${bySrc.alt}"`}`;
    else actual = `no image with this alt text; the page has ${imgs.length} image element(s)${imgs.length ? `: ${imgs.map((i) => `${i.path} alt=${i.alt === null ? '(missing)' : `"${i.alt}"`}`).join('; ')}` : ''}`;
    check.failures.push({
      what: `design photo ${d.exportNames[0] || d.hash} is not on the page with its alt text`,
      where: `${width}px · ${d.where.join(', ')}`,
      expected: `a rendered image with alt="${d.alt}" (design/data/images.json › ${d.hash})`,
      actual,
    });
  }
}
