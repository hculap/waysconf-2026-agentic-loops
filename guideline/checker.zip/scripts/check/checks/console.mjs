// Check 2: loading the page produces no errors in the browser console.
export function run({ width, events, check }) {
  check.count++;
  for (const e of events) {
    check.failures.push({
      what: `browser ${e.kind} while loading the page`,
      where: `${width}px${e.source ? ` · ${e.source}` : ''}`,
      expected: 'no console errors, uncaught exceptions or failed requests',
      actual: e.text,
    });
  }
}
