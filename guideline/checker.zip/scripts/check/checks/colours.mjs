// Check 5: every colour the page paints is one the design defines.
import { describe, hex } from '../colour.mjs';

const RGB_TOLERANCE = 1; // 8-bit rounding when a token is written as oklch/hsl
const ALPHA_TOLERANCE = 0.01;

export function allowedList(tokens) {
  return tokens.map((t) => `${t.name} ${t.hex} (alpha ${t.alphas.map((a) => a.a).join(', ')})`).join('; ');
}

function judge(rgba, tokens) {
  if (!rgba || rgba.some((v) => !Number.isFinite(v))) return { ok: false, reason: 'unreadable' };
  if (rgba[3] <= 0.001) return { ok: true, skip: true };
  let nearest = null;
  for (const t of tokens) {
    const delta = Math.max(...t.rgb.map((v, i) => Math.abs(v - rgba[i])));
    if (!nearest || delta < nearest.delta) nearest = { token: t, delta };
    if (delta <= RGB_TOLERANCE && t.alphas.some((a) => Math.abs(a.a - rgba[3]) <= ALPHA_TOLERANCE)) return { ok: true };
  }
  return { ok: false, nearest };
}

export async function run({ page, width, design, check }) {
  const tokens = design.colours;
  const { paints, svgImages } = await page.evaluate(() => window.__chk.collectPaints());

  for (const img of svgImages) {
    let text;
    try {
      const res = await page.request.get(img.src);
      if (!res.ok()) throw new Error(`HTTP ${res.status()}`);
      text = await res.text();
    } catch (err) {
      check.failures.push({ what: 'colours of an SVG image could not be read', where: `${width}px · ${img.path} · ${img.section} · src ${img.src}`, expected: 'a readable SVG whose fills and strokes are design colours', actual: `fetch failed: ${err.message}` });
      continue;
    }
    const r = await page.evaluate(([t, i]) => window.__chk.svgImagePaints(t, i), [text, img]);
    if (r.error) check.failures.push({ what: 'colours of an SVG image could not be read', where: `${width}px · ${img.path} · src ${img.src}`, expected: 'a parseable SVG', actual: r.error });
    else paints.push(...r.paints);
  }

  // Keyboard focus states: Tab through every focusable element once.
  const max = (await page.evaluate(() => window.__chk.focusableCount())) + 2;
  const seen = new Set();
  await page.evaluate(() => { document.activeElement?.blur?.(); window.scrollTo({ top: 0, behavior: 'instant' }); });
  for (let i = 0; i < max; i++) {
    await page.keyboard.press('Tab');
    await page.evaluate(() => window.__chk.settle());
    const f = await page.evaluate(() => window.__chk.focusPaints());
    if (!f || seen.has(f.key)) break;
    seen.add(f.key);
    paints.push(...f.paints);
  }
  await page.evaluate(() => { document.activeElement?.blur?.(); window.scrollTo({ top: 0, behavior: 'instant' }); window.__chk.settle(); });

  check.groups ??= new Map();
  for (const p of paints) {
    check.count++;
    if (p.nativeControl) {
      addGroup(check, `native|${p.value}`, { what: 'a form control is painted with browser-default colours', expected: `a custom-styled control using design colours (appearance: none): ${allowedList(tokens)}`, actual: p.value }, width, p);
      continue;
    }
    const v = judge(p.rgba, tokens);
    if (v.ok) continue;
    const measured = v.reason === 'unreadable' ? `unreadable colour value "${p.value}"` : `${describe(p.rgba)} (computed "${p.value}")`;
    const expected = v.nearest
      ? `a design colour. Nearest: ${v.nearest.token.name} ${v.nearest.token.hex} (ΔRGB ${v.nearest.delta}, allowed alpha ${v.nearest.token.alphas.map((a) => a.a).join(', ')}); tolerance ±${RGB_TOLERANCE} per channel, ±${ALPHA_TOLERANCE} alpha (design/data/colours.json)`
      : 'a design colour (design/data/colours.json)';
    const key = p.rgba ? `${hex(p.rgba)}|${Math.round(p.rgba[3] * 1000)}` : `bad|${p.value}`;
    addGroup(check, key, { what: `paints a colour the design does not define: ${measured.split(' (computed')[0]}`, expected, actual: measured }, width, p);
  }
}

function addGroup(check, key, base, width, p) {
  if (!check.groups.has(key)) check.groups.set(key, { ...base, places: new Set() });
  check.groups.get(key).places.add(`${width}px · ${p.prop}${p.state !== 'default' ? ` (${p.state})` : ''} · ${p.path} · ${p.section} · ${p.box}${p.text ? ` · "${p.text}"` : ''}`);
}

export function finalize(check) {
  for (const g of [...(check.groups || new Map()).values()].sort((a, b) => a.what.localeCompare(b.what))) {
    const places = [...g.places].sort();
    check.failures.push({ what: `${g.what} (${places.length} place${places.length === 1 ? '' : 's'})`, where: places.join('\n'), expected: g.expected, actual: g.actual });
  }
  delete check.groups;
}
