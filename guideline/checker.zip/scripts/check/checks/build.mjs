// Check 1: the project builds, with no errors.
import { spawn } from 'node:child_process';
import path from 'node:path';

const ANSI = /\x1b\[[0-9;]*[A-Za-z]/g;
const ERROR_LINE = /\[ERROR\]|^\s*error\b|^\s*\w*Error:/i;

export function runBuild(root) {
  return new Promise((resolve) => {
    const astro = path.join(root, 'node_modules', 'astro', 'bin', 'astro.mjs');
    const child = spawn(process.execPath, [astro, 'build'], {
      cwd: root,
      env: { ...process.env, ASTRO_TELEMETRY_DISABLED: '1', FORCE_COLOR: '0', CI: '1' },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let output = '';
    child.stdout.on('data', (d) => (output += d));
    child.stderr.on('data', (d) => (output += d));
    child.on('error', (err) => resolve({ ran: false, reason: `could not start astro build: ${err.message}` }));
    child.on('close', (code) => {
      const lines = output.replace(ANSI, '').split('\n');
      resolve({ ran: true, code, errorLines: lines.filter((l) => ERROR_LINE.test(l)).map((l) => l.trim()), tail: lines.filter(Boolean).slice(-15) });
    });
  });
}

export function judgeBuild(result, check) {
  if (!result.ran) {
    check.notRun.push(result.reason);
    return;
  }
  check.count++;
  if (result.code !== 0) {
    check.failures.push({
      what: `astro build exited with code ${result.code}`,
      where: 'astro build (project root)',
      expected: 'exit code 0 and no error lines',
      actual: `exit code ${result.code}. Last output:\n${result.tail.join('\n')}`,
    });
  }
  for (const line of result.errorLines) {
    check.failures.push({
      what: 'astro build printed an error',
      where: 'astro build output',
      expected: 'no error lines',
      actual: line,
    });
  }
}
