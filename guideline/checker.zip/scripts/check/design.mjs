// Loads design/data/*.json and derives everything the checker expects of the page.
// Nothing here is typed in by hand: every expectation points back to a file and field.
import fs from 'node:fs';
import path from 'node:path';

const FILES = ['sections', 'colours', 'copy', 'images'];

export class DesignError extends Error {}

function need(cond, message) {
  if (!cond) throw new DesignError(message);
}

export function loadDesign(root) {
  const dir = path.join(root, 'design', 'data');
  need(fs.existsSync(dir), `design/data is missing (looked for ${dir})`);
  const data = {};
  for (const name of FILES) {
    const file = path.join(dir, `${name}.json`);
    need(fs.existsSync(file), `design/data/${name}.json is missing`);
    try {
      data[name] = JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (err) {
      throw new DesignError(`design/data/${name}.json is not valid JSON: ${err.message}`);
    }
  }
  const widths = deriveWidths(data.sections);
  return {
    widths,
    narrowest: Math.min(...widths),
    sections: deriveSections(data.sections, widths),
    colours: deriveColours(data.colours, data.sections, root),
    copy: deriveCopy(data.copy, data.sections, widths),
    images: deriveImages(data.images, widths),
  };
}

// ---------------------------------------------------------------- widths

function deriveWidths(sections) {
  need(Array.isArray(sections.widths) && sections.widths.length > 0, 'design/data/sections.json › widths is empty or missing');
  for (const w of sections.widths) need(Number.isFinite(w) && w > 0, `design/data/sections.json › widths contains an invalid width: ${JSON.stringify(w)}`);
  return [...sections.widths].sort((a, b) => b - a);
}

// ---------------------------------------------------------------- sections

// Turns a section's design note into a CSS selector, e.g.
// `section id="hero" data-section="hero"` -> section[id="hero"][data-section="hero"]
// `nav landmark, aria-label="Primary"`   -> nav[aria-label="Primary"]
export function selectorFromNotes(notes) {
  const text = (notes || []).join(' ');
  const first = (notes || [])[0] || '';
  const tag = (first.match(/^(section|nav|footer|header|main|aside)\b/) || [])[1] || '';
  const attrs = [];
  const id = text.match(/(?:^|[\s,])id="([^"]+)"/);
  const ds = text.match(/data-section="([^"]+)"/);
  const aria = text.match(/aria-label="([^"]+)"/);
  if (id) attrs.push(`[id="${id[1]}"]`);
  if (ds) attrs.push(`[data-section="${ds[1]}"]`);
  if (aria) attrs.push(`[aria-label="${aria[1]}"]`);
  if (!attrs.length) return null;
  return tag + attrs.join('');
}

function deriveSections(sections, widths) {
  need(sections.orderByWidth && typeof sections.orderByWidth === 'object', 'design/data/sections.json › orderByWidth is missing');
  need(Array.isArray(sections.sections) && sections.sections.length > 0, 'design/data/sections.json › sections is empty or missing');
  const byName = new Map(sections.sections.map((s) => [s.name, s]));
  const out = {};
  for (const w of widths) {
    const order = sections.orderByWidth[w];
    need(Array.isArray(order) && order.length > 0, `design/data/sections.json › orderByWidth[${w}] is empty or missing`);
    out[w] = order.map((name) => {
      const sec = byName.get(name);
      need(sec, `design/data/sections.json › orderByWidth[${w}] names "${name}", which is not in sections`);
      const notes = sec.byWidth?.[w]?.node?.notes || [];
      let selector = selectorFromNotes(notes);
      let source = `design/data/sections.json › ${name} › byWidth[${w}] › node.notes: ${JSON.stringify(notes[0] || '')}`;
      if (!selector) {
        // No selector in the design; follow the pattern every other section uses
        // (notes.md, assumption 20: the ticker gets id + data-section).
        const short = name.replace(/^section-/, '');
        selector = `[id="${short}"][data-section="${short}"]`;
        source = `design/data/sections.json › ${name} has no selector note; the pattern of the other sections applies (notes.md assumption 20)`;
      }
      return { name, selector, source, notes };
    });
  }
  return out;
}

// ---------------------------------------------------------------- colours

const hexOf = ({ r, g, b }) =>
  '#' + [r, g, b].map((c) => Math.round(c * 255).toString(16).padStart(2, '0')).join('');
const rgbOfHex = (hex) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));

function deriveColours(colours, sections, root) {
  need(Array.isArray(colours.colours) && colours.colours.length > 0, 'design/data/colours.json › colours is empty or missing');
  const tokens = colours.colours.map((c) => {
    need(/^#[0-9a-f]{6}$/i.test(c.hex || ''), `design/data/colours.json › ${c.name} has no 6-digit hex`);
    return { name: c.name, hex: c.hex.toLowerCase(), rgb: rgbOfHex(c.hex.toLowerCase()) };
  });
  const tokenFor = (hex) => {
    const rgb = rgbOfHex(hex);
    return tokens.find((t) => t.rgb.every((v, i) => Math.abs(v - rgb[i]) <= 1));
  };
  // alpha levels the design paints each token at (fills, strokes, gradient stops, x paint and node opacity)
  const alphas = new Map(tokens.map((t) => [t.hex, new Map([[1, 'solid token']])]));
  const addAlpha = (hex, a, where) => {
    const t = tokenFor(hex);
    if (!t || a <= 0) return;
    const key = Math.round(a * 1000) / 1000;
    const m = alphas.get(t.hex);
    if (!m.has(key)) m.set(key, where);
  };
  const walk = (obj, op, where) => {
    if (!obj || typeof obj !== 'object') return;
    if (Array.isArray(obj)) return obj.forEach((x) => walk(x, op, where));
    const isNode = typeof obj.type === 'string' && 'visible' in obj;
    if (isNode && obj.visible === false) return;
    const nodeOp = isNode ? op * (obj.opacity ?? 1) : op;
    const here = isNode && obj.name ? obj.name : where;
    for (const key of ['fills', 'strokes']) {
      if (!Array.isArray(obj[key])) continue;
      for (const p of obj[key]) {
        if (p.visible === false) continue;
        const stops = p.gradientStops || [p];
        for (const s of stops) if (s.color) addAlpha(hexOf(s.color), s.color.a * (p.opacity ?? 1) * nodeOp, here);
      }
    }
    for (const [k, v] of Object.entries(obj)) if (k !== 'fills' && k !== 'strokes' && typeof v === 'object') walk(v, nodeOp, here);
  };
  walk(sections.sections, 1, 'page');
  walk(sections.otherFrames, 1, 'page');
  const compFile = path.join(root, 'design', 'data', 'components.json');
  need(fs.existsSync(compFile), 'design/data/components.json is missing');
  walk(JSON.parse(fs.readFileSync(compFile, 'utf8')), 1, 'components');
  return tokens.map((t) => ({
    ...t,
    alphas: [...alphas.get(t.hex).entries()].map(([a, where]) => ({ a, where })).sort((x, y) => y.a - x.a),
  }));
}

// ---------------------------------------------------------------- copy

function deriveCopy(copy, sections, widths) {
  need(Array.isArray(copy.sections) && copy.sections.length > 0, 'design/data/copy.json › sections is empty or missing');
  const entries = [];
  for (const sec of copy.sections) {
    for (const e of sec.entries || []) {
      if (e.kind !== 'text') continue;
      need(typeof e.text === 'string', `design/data/copy.json › ${sec.name} has a text entry without text`);
      entries.push({ section: sec.name, text: e.text, widths: e.widths || [], hiddenAt: e.hiddenAt || [], key: e.key, state: 'default' });
    }
  }
  need(entries.length > 0, 'design/data/copy.json has no text entries');
  // Other frames, e.g. "TURBINE / Mobile 390 / menu open": copy shown after an interaction.
  const frames = sections.otherFrames || [];
  const menu = [];
  for (const f of copy.otherFrames || []) {
    const frame = frames.find((x) => x.name === f.name);
    need(frame, `design/data/copy.json › otherFrames names "${f.name}", which sections.json › otherFrames does not describe`);
    for (const e of f.entries || []) {
      if (e.kind !== 'text') continue;
      menu.push({ section: 'section-nav', text: e.text, widths: [frame.width], hiddenAt: e.hiddenAt || [], key: `${f.name} › ${e.key}`, state: f.name });
    }
  }
  // The nav note names the button that opens the menu.
  const navNotes = (sections.sections.find((s) => s.name === 'section-nav')?.byWidth?.[Math.min(...widths)]?.node?.notes || []).join(' ');
  const toggle = navNotes.match(/accessible name toggles (.+?) \/ (.+?)\./);
  return {
    entries,
    menu,
    openMenuName: toggle ? toggle[1].trim() : null,
    openMenuSource: `design/data/sections.json › section-nav › notes: ${JSON.stringify(navNotes)}`,
  };
}

// ---------------------------------------------------------------- images

function deriveImages(images, widths) {
  need(Array.isArray(images.images) && images.images.length > 0, 'design/data/images.json › images is empty or missing');
  const out = [];
  for (const img of images.images) {
    const used = (img.usedBy || []).filter((u) => widths.includes(u.width));
    if (!used.length) continue;
    need(Array.isArray(img.alt) && img.alt.length === 1 && img.alt[0].trim(), `design/data/images.json › ${img.hash} is used on the page but has no single alt text`);
    out.push({
      hash: img.hash,
      exportNames: img.exportNames || [],
      alt: img.alt[0],
      widths: [...new Set(used.map((u) => u.width))].sort((a, b) => b - a),
      where: [...new Set(used.map((u) => `${u.section} › ${u.node}`))],
    });
  }
  need(out.length > 0, 'design/data/images.json › no image is used on a page frame');
  const allNames = images.images.flatMap((i) => [i.hash, ...(i.exportNames || []), ...(i.assetFrames || [])]);
  return { onPage: out, fileNames: allNames };
}
