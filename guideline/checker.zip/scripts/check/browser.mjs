// Opens the page in real Chromium at a given width and brings it to a stable, repeatable state.
import { chromium } from 'playwright';

export const VIEWPORT_HEIGHT = 900;

export async function launch() {
  return chromium.launch({ headless: true });
}

export async function openPage(browser, url, width) {
  const context = await browser.newContext({
    viewport: { width, height: VIEWPORT_HEIGHT },
    deviceScaleFactor: 1,
    colorScheme: 'light',
    reducedMotion: 'no-preference',
    locale: 'en-GB',
    timezoneId: 'Europe/Warsaw',
  });
  const page = await context.newPage();
  const events = [];
  page.on('console', (msg) => {
    if (msg.type() !== 'error') return;
    const loc = msg.location();
    events.push({ kind: 'console.error', text: msg.text(), source: loc?.url ? `${loc.url}:${loc.lineNumber}:${loc.columnNumber}` : '' });
  });
  page.on('pageerror', (err) => events.push({ kind: 'uncaught exception', text: String(err?.stack || err), source: '' }));
  page.on('requestfailed', (req) => events.push({ kind: 'request failed', text: `${req.failure()?.errorText || 'failed'}`, source: req.url() }));
  page.on('response', (res) => {
    if (res.status() >= 400) events.push({ kind: `HTTP ${res.status()}`, text: `${res.request().method()} returned ${res.status()} ${res.statusText()}`, source: res.url() });
  });

  let response;
  try {
    response = await page.goto(url, { waitUntil: 'load', timeout: 45000 });
  } catch (err) {
    await context.close();
    throw new Error(`the page did not load at ${width}px: ${err.message.split('\n')[0]}`);
  }
  if (!response) {
    await context.close();
    throw new Error(`the page did not load at ${width}px: no response`);
  }
  if (response.status() >= 400) {
    await context.close();
    throw new Error(`the page did not load at ${width}px: HTTP ${response.status()} ${response.statusText()}`);
  }
  await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
  await page.evaluate(installHelpers);
  await page.evaluate(() => window.__chk.stabilise());
  await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
  await page.evaluate(() => window.__chk.settle());
  return { page, context, events };
}

// Everything below runs inside the page (serialised by page.evaluate).
export function installHelpers() {
  if (window.__chk) return;
  const frames = (n) => new Promise((r) => { const step = () => (n-- <= 0 ? r() : requestAnimationFrame(step)); step(); });

  const settle = () => {
    for (const a of document.getAnimations()) {
      const t = a.effect && a.effect.getComputedTiming ? a.effect.getComputedTiming() : null;
      if (t && Number.isFinite(t.endTime)) a.finish();
      else a.cancel();
    }
  };

  const stabilise = async () => {
    await document.fonts.ready;
    const step = window.innerHeight;
    for (let y = 0; y < document.documentElement.scrollHeight; y += step) {
      window.scrollTo({ top: y, left: 0, behavior: 'instant' });
      await frames(2);
    }
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    await frames(2);
    const pending = [...document.images].filter((i) => !i.complete);
    await Promise.race([
      Promise.all(pending.map((i) => new Promise((r) => { i.addEventListener('load', r, { once: true }); i.addEventListener('error', r, { once: true }); }))),
      new Promise((r) => setTimeout(r, 15000)),
    ]);
    await document.fonts.ready;
    settle();
    await frames(2);
  };

  const pathOf = (el) => {
    if (!el || el.nodeType !== 1) return String(el);
    const parts = [];
    let e = el;
    while (e && e.nodeType === 1 && parts.length < 7) {
      let s = e.localName;
      if (e.id) { parts.unshift(`${s}#${CSS.escape(e.id)}`); break; }
      const ds = e.getAttribute('data-section');
      if (ds) s += `[data-section="${ds}"]`;
      else if (e.classList && e.classList.length) s += '.' + [...e.classList].slice(0, 2).map((c) => CSS.escape(c)).join('.');
      const p = e.parentElement;
      if (p) {
        const same = [...p.children].filter((c) => c.localName === e.localName);
        if (same.length > 1) s += `:nth-of-type(${same.indexOf(e) + 1})`;
      }
      parts.unshift(s);
      if (e.localName === 'body' || e.localName === 'html') break;
      e = p;
    }
    return parts.join(' > ');
  };

  const sectionOf = (el) => {
    const s = el && el.closest && el.closest('[data-section], nav, footer, header, main');
    if (!s) return '(outside any section)';
    return s.getAttribute('data-section') ? `section "${s.getAttribute('data-section')}"` : `<${s.localName}>`;
  };

  const boxOf = (el) => {
    const r = el.getBoundingClientRect();
    return `x ${Math.round(r.left + scrollX)}, y ${Math.round(r.top + scrollY)}, ${Math.round(r.width)}×${Math.round(r.height)}`;
  };

  const snippet = (el) => (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 60);

  const where = (el) => ({ path: pathOf(el), section: sectionOf(el), box: boxOf(el), text: snippet(el) });

  // colour string -> [r,g,b,a] in 8-bit sRGB
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 1;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const parseColour = (str) => {
    if (!str) return null;
    str = str.trim();
    if (str === 'transparent') return [0, 0, 0, 0];
    let m = str.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/);
    if (m) {
      let a = m[4] === undefined ? 1 : m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
      return [Math.round(+m[1]), Math.round(+m[2]), Math.round(+m[3]), a];
    }
    let alpha = 1;
    let opaque = str;
    m = str.match(/^([a-z-]+)\((.*)\)$/i);
    if (m && m[2].includes('/')) {
      const [body, a] = m[2].split('/');
      alpha = a.trim().endsWith('%') ? parseFloat(a) / 100 : parseFloat(a);
      opaque = `${m[1]}(${body.trim()})`;
    }
    ctx.clearRect(0, 0, 1, 1);
    ctx.fillStyle = '#010203';
    ctx.fillStyle = opaque;
    ctx.fillRect(0, 0, 1, 1);
    const d = ctx.getImageData(0, 0, 1, 1).data;
    if (!Number.isFinite(alpha)) return null;
    return [d[0], d[1], d[2], alpha];
  };
  const COLOUR_TOKEN = /(?:rgba?|hsla?|hwb|lab|lch|oklab|oklch|color)\([^()]*\)|#[0-9a-f]{3,8}\b/gi;

  const effectiveOpacity = (el) => {
    let o = 1;
    for (let e = el; e && e.nodeType === 1; e = e.parentElement) o *= parseFloat(getComputedStyle(e).opacity);
    return o;
  };

  // Is a text node visibly rendered (not display:none, not visibility:hidden, not opacity 0,
  // not clipped away by a visually-hidden pattern)?
  const hiddenCache = new WeakMap();
  const elementHidden = (el) => {
    if (hiddenCache.has(el)) return hiddenCache.get(el);
    let hidden = false;
    if (!el.checkVisibility({ visibilityProperty: true, opacityProperty: true, contentVisibilityAuto: false })) hidden = true;
    else {
      for (let e = el; e && e.nodeType === 1 && e !== document.body; e = e.parentElement) {
        const cs = getComputedStyle(e);
        const r = e.getBoundingClientRect();
        if (cs.clip && cs.clip !== 'auto' && /rect\(0px,? 0px,? 0px,? 0px\)/.test(cs.clip)) { hidden = true; break; }
        if (/inset\((50|100)%/.test(cs.clipPath)) { hidden = true; break; }
        if (cs.overflow !== 'visible' && (r.width <= 1 || r.height <= 1)) { hidden = true; break; }
      }
    }
    hiddenCache.set(el, hidden);
    return hidden;
  };
  const textNodeVisible = (node) => {
    const el = node.parentElement;
    if (!el || elementHidden(el)) return false;
    const range = document.createRange();
    range.selectNodeContents(node);
    return [...range.getClientRects()].some((r) => r.width > 1 && r.height > 1);
  };

  const SKIP = new Set(['script', 'style', 'template', 'noscript', 'head', 'title', 'meta', 'link']);
  const TEXT_INPUTS = new Set(['text', 'email', 'search', 'tel', 'url', 'number', 'password', '']);
  // Returns { all, visible } text of a container with block boundaries as spaces.
  const textOf = (container) => {
    let all = '';
    let visible = '';
    const visit = (node) => {
      if (node.nodeType === 3) {
        all += node.data;
        visible += textNodeVisible(node) ? node.data : ' ';
        return;
      }
      if (node.nodeType !== 1) return;
      const tag = node.localName;
      if (SKIP.has(tag)) return;
      if (tag === 'br') { all += ' '; visible += ' '; return; }
      const display = node.isConnected ? getComputedStyle(node).display : 'inline';
      const boundary = display !== 'inline' && display !== 'contents';
      if (boundary) { all += ' '; visible += ' '; }
      if (tag === 'input' || tag === 'textarea') {
        const type = (node.getAttribute('type') || '').toLowerCase();
        const vis = !elementHidden(node);
        const bits = [];
        if (tag === 'textarea' || TEXT_INPUTS.has(type)) {
          if (node.value) bits.push(node.value);
          else if (node.placeholder) bits.push(node.placeholder);
        } else if (['submit', 'button', 'reset'].includes(type) && node.value) bits.push(node.value);
        for (const b of bits) { all += ` ${b} `; visible += vis ? ` ${b} ` : ' '; }
      } else if (tag === 'select') {
        const opt = node.selectedOptions && node.selectedOptions[0];
        if (opt) { all += ` ${opt.text} `; visible += elementHidden(node) ? ' ' : ` ${opt.text} `; }
      } else {
        const kids = node.shadowRoot ? node.shadowRoot.childNodes : node.childNodes;
        for (const c of kids) visit(c);
      }
      if (boundary) { all += ' '; visible += ' '; }
    };
    visit(container);
    const norm = (s) => s.replace(/[\s ]+/g, ' ').trim();
    return { all: norm(all), visible: norm(visible) };
  };

  // Every colour an element paints, from computed style.
  const paintsOf = (el, state) => {
    const out = [];
    const cs = getComputedStyle(el);
    const op = effectiveOpacity(el);
    const add = (prop, value, pseudo = '') => {
      const rgba = parseColour(value);
      out.push({ prop: pseudo ? `${pseudo} ${prop}` : prop, value, rgba: rgba ? [rgba[0], rgba[1], rgba[2], rgba[3] * op] : null, state });
    };
    const addAll = (prop, str, pseudo) => { for (const c of (str || '').match(COLOUR_TOKEN) || []) add(prop, c, pseudo); };
    const boxPaints = (s, pseudo) => {
      add('background-color', s.backgroundColor, pseudo);
      if (s.backgroundImage && s.backgroundImage !== 'none') addAll('background-image', s.backgroundImage.replace(/url\([^)]*\)/g, ''), pseudo);
      for (const side of ['Top', 'Right', 'Bottom', 'Left']) {
        if (parseFloat(s[`border${side}Width`]) > 0 && !['none', 'hidden'].includes(s[`border${side}Style`])) add(`border-${side.toLowerCase()}-color`, s[`border${side}Color`], pseudo);
      }
      if (s.outlineStyle !== 'none' && parseFloat(s.outlineWidth) > 0) add('outline-color', s.outlineColor, pseudo);
      if (s.boxShadow && s.boxShadow !== 'none') addAll('box-shadow', s.boxShadow, pseudo);
    };
    const svgNs = el.namespaceURI === 'http://www.w3.org/2000/svg';
    if (svgNs) {
      const SHAPES = ['path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'text', 'tspan', 'textPath', 'use'];
      if (SHAPES.includes(el.localName)) {
        if (cs.fill && cs.fill !== 'none' && !cs.fill.startsWith('url(')) out.push(...[cs.fill].map((v) => { const c = parseColour(v); return { prop: 'fill', value: v, rgba: c ? [c[0], c[1], c[2], c[3] * op * parseFloat(cs.fillOpacity)] : null, state }; }));
        if (cs.stroke && cs.stroke !== 'none' && !cs.stroke.startsWith('url(') && parseFloat(cs.strokeWidth) > 0) { const c = parseColour(cs.stroke); out.push({ prop: 'stroke', value: cs.stroke, rgba: c ? [c[0], c[1], c[2], c[3] * op * parseFloat(cs.strokeOpacity)] : null, state }); }
      }
      if (el.localName === 'stop') { const c = parseColour(cs.stopColor); out.push({ prop: 'stop-color', value: cs.stopColor, rgba: c ? [c[0], c[1], c[2], c[3] * parseFloat(cs.stopOpacity)] : null, state }); }
      if (el.localName === 'svg') boxPaints(cs, '');
      return out;
    }
    boxPaints(cs, '');
    const ownText = [...el.childNodes].some((n) => n.nodeType === 3 && n.data.trim());
    const isField = ['input', 'textarea', 'select', 'button'].includes(el.localName);
    if (ownText || (isField && (el.value || el.localName === 'select'))) {
      add('color', cs.color);
      if (cs.webkitTextFillColor && cs.webkitTextFillColor !== cs.color) add('-webkit-text-fill-color', cs.webkitTextFillColor);
      if (cs.textDecorationLine && cs.textDecorationLine !== 'none') add('text-decoration-color', cs.textDecorationColor);
      if (cs.textShadow && cs.textShadow !== 'none') addAll('text-shadow', cs.textShadow);
    }
    if ((el.localName === 'input' || el.localName === 'textarea') && el.placeholder && !el.value) {
      add('color', getComputedStyle(el, '::placeholder').color, '::placeholder');
    }
    const type = (el.getAttribute('type') || '').toLowerCase();
    if ((el.localName === 'input' && ['checkbox', 'radio', 'range', 'color', 'file'].includes(type)) || ['progress', 'meter'].includes(el.localName) || (el.localName === 'select')) {
      if (cs.appearance !== 'none' && cs.webkitAppearance !== 'none') out.push({ prop: 'native control appearance', value: `appearance: ${cs.appearance} (browser-default control colours, accent-color ${cs.accentColor})`, rgba: null, state, nativeControl: true });
    }
    for (const pseudo of ['::before', '::after']) {
      const ps = getComputedStyle(el, pseudo);
      if (!ps.content || ps.content === 'none' || ps.content === 'normal' || ps.display === 'none') continue;
      boxPaints(ps, pseudo);
      if (ps.content !== '""' && ps.content !== "''") {
        add('color', ps.color, pseudo);
        if (ps.textDecorationLine !== 'none') add('text-decoration-color', ps.textDecorationColor, pseudo);
        if (ps.textShadow && ps.textShadow !== 'none') addAll('text-shadow', ps.textShadow, pseudo);
      }
    }
    if (cs.display === 'list-item' && cs.listStyleType !== 'none' && cs.listStyleImage === 'none') {
      add('color', getComputedStyle(el, '::marker').color, '::marker');
    }
    return out;
  };

  const collectPaints = () => {
    const results = [];
    const html = document.documentElement;
    const body = document.body;
    const bgTransparent = (el) => { const c = el && parseColour(getComputedStyle(el).backgroundColor); return !c || c[3] === 0; };
    if (bgTransparent(html) && bgTransparent(body)) {
      const probe = document.createElement('div');
      probe.style.cssText = 'position:absolute;width:0;height:0;background-color:Canvas';
      html.appendChild(probe);
      const canvasColour = getComputedStyle(probe).backgroundColor;
      probe.remove();
      results.push({ path: 'html (page canvas)', section: '(whole page)', box: `0, 0, ${html.scrollWidth}×${html.scrollHeight}`, text: '', prop: 'canvas background (html and body have no background)', value: canvasColour, rgba: parseColour(canvasColour), state: 'default' });
    }
    for (const el of document.querySelectorAll('*')) {
      if (el.closest('head')) continue;
      if (!el.checkVisibility({ visibilityProperty: true })) continue;
      const w = where(el);
      for (const p of paintsOf(el, 'default')) results.push({ ...w, ...p });
    }
    const svgImages = [...document.querySelectorAll('img')].filter((i) => /\.svg(\?|#|$)/i.test(i.currentSrc || i.src) && i.checkVisibility({ visibilityProperty: true })).map((i) => ({ ...where(i), src: i.currentSrc || i.src, opacity: effectiveOpacity(i) }));
    return { paints: results, svgImages };
  };

  const focusPaints = () => {
    const el = document.activeElement;
    if (!el || el === document.body || el === document.documentElement) return null;
    return { key: pathOf(el), paints: paintsOf(el, 'keyboard focus').map((p) => ({ ...where(el), ...p })) };
  };

  const sections = (expected) => expected.map((s) => {
    let els;
    try { els = [...document.querySelectorAll(s.selector)]; } catch (err) { return { ...s, error: err.message, count: 0, found: [] }; }
    return {
      ...s,
      count: els.length,
      found: els.map((el) => {
        const r = el.getBoundingClientRect();
        return { path: pathOf(el), visible: el.checkVisibility({ visibilityProperty: true, opacityProperty: true }) && r.height > 0 && r.width > 0, top: Math.round(r.top + scrollY), height: Math.round(r.height) };
      }),
      domIndex: els.length === 1 ? [...document.querySelectorAll('*')].indexOf(els[0]) : -1,
    };
  });

  const landmarkInventory = () => [...document.querySelectorAll('[data-section], section, nav, footer, header, main, [role=navigation], [role=contentinfo], [role=main]')].map((el) => {
    const r = el.getBoundingClientRect();
    return `${pathOf(el)}${el.getAttribute('aria-label') ? ` aria-label="${el.getAttribute('aria-label')}"` : ''} (top ${Math.round(r.top + scrollY)})`;
  });

  const copyTexts = (selectors) => {
    const out = {};
    for (const [name, sel] of Object.entries(selectors)) {
      let el = null;
      try { const all = document.querySelectorAll(sel); if (all.length === 1) el = all[0]; } catch {}
      out[name] = el ? { found: true, ...textOf(el) } : { found: false };
    }
    out.__page = { found: true, ...textOf(document.body || document.documentElement) };
    return out;
  };

  const images = () => [...document.querySelectorAll('img, input[type="image" i], [role="img"]')].map((el) => {
    let name = null;
    if (el.localName === 'img' || el.localName === 'input') name = el.getAttribute('alt');
    else {
      name = el.getAttribute('aria-label');
      const lb = el.getAttribute('aria-labelledby');
      if (!name && lb) name = lb.split(/\s+/).map((id) => document.getElementById(id)?.textContent || '').join(' ');
      if (!name && el.localName === 'svg') name = el.querySelector(':scope > title')?.textContent || null;
      if (!name && el.getAttribute('alt') !== null) name = el.getAttribute('alt');
    }
    const r = el.getBoundingClientRect();
    return {
      ...where(el),
      tag: el.localName,
      src: el.currentSrc || el.getAttribute('src') || '',
      alt: name,
      visible: el.checkVisibility({ visibilityProperty: true, opacityProperty: true }) && r.width > 0 && r.height > 0,
    };
  });

  const overflow = () => {
    const html = document.documentElement;
    const cw = html.clientWidth;
    const offenders = [];
    for (const el of document.body ? document.body.querySelectorAll('*') : []) {
      if (el.closest('svg') && el.localName !== 'svg') continue;
      if (elementHidden(el)) continue;
      const r = el.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) continue;
      if (r.right <= cw + 0.5 && r.left >= -0.5) continue;
      if (getComputedStyle(el).position === 'fixed' && getComputedStyle(el).visibility === 'hidden') continue;
      let clipped = false;
      for (let a = el.parentElement; a && a !== document.body && a !== html; a = a.parentElement) {
        const cs = getComputedStyle(a);
        if (cs.overflowX !== 'visible') {
          const ar = a.getBoundingClientRect();
          if (ar.left >= -0.5 && ar.right <= cw + 0.5) { clipped = true; break; }
        }
      }
      if (clipped) continue;
      offenders.push({ ...where(el), left: Math.round(r.left * 10) / 10, right: Math.round(r.right * 10) / 10 });
    }
    return { scrollWidth: html.scrollWidth, bodyScrollWidth: document.body ? document.body.scrollWidth : 0, clientWidth: cw, offenders };
  };

  // Hide an element's own text (descendants keep their colours) for the pixel contrast measurement.
  const saved = new Map();
  const hideOwnText = (sel) => {
    const el = document.querySelector(sel);
    if (!el) return null;
    const cs = getComputedStyle(el);
    const info = {
      where: where(el),
      color: parseColour(cs.webkitTextFillColor || cs.color),
      colorValue: cs.webkitTextFillColor || cs.color,
      opacity: effectiveOpacity(el),
      fontSize: parseFloat(cs.fontSize),
      fontWeight: parseInt(cs.fontWeight, 10),
    };
    const targets = [el, ...el.querySelectorAll('*')];
    const keep = targets.map((t) => { const s = getComputedStyle(t); return [t, s.color, s.webkitTextFillColor, s.textShadow]; });
    saved.set(sel, targets.map((t) => [t, t.getAttribute('style')]));
    for (const [t, color, fill, shadow] of keep) {
      if (t === el) {
        t.style.setProperty('color', 'transparent', 'important');
        t.style.setProperty('-webkit-text-fill-color', 'transparent', 'important');
        t.style.setProperty('text-shadow', 'none', 'important');
        t.style.setProperty('text-decoration-color', 'transparent', 'important');
      } else {
        t.style.setProperty('color', color, 'important');
        t.style.setProperty('-webkit-text-fill-color', fill, 'important');
        t.style.setProperty('text-shadow', shadow, 'important');
      }
    }
    settle();
    return info;
  };
  const restoreText = (sel) => {
    for (const [t, style] of saved.get(sel) || []) {
      if (style === null) t.removeAttribute('style');
      else t.setAttribute('style', style);
    }
    saved.delete(sel);
    settle();
  };
  const prepareForShot = (sel) => {
    const el = document.querySelector(sel);
    if (!el) return null;
    el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    settle();
    const r = el.getBoundingClientRect();
    const x = Math.max(0, Math.floor(r.left));
    const y = Math.max(0, Math.floor(r.top));
    const right = Math.min(document.documentElement.clientWidth, Math.ceil(r.right));
    const bottom = Math.min(window.innerHeight, Math.ceil(r.bottom));
    return { x, y, width: right - x, height: bottom - y, scrollX, scrollY };
  };

  // Colours painted by an SVG file shown through <img>: parse it into an isolated shadow root
  // (no page CSS, currentColor = initial black, as inside an <img>) and read its computed paints.
  const svgImagePaints = (svgText, img) => {
    const doc = new DOMParser().parseFromString(svgText, 'image/svg+xml');
    const root = doc.documentElement;
    if (!root || root.localName !== 'svg') return { error: `not an SVG document (${root ? root.localName : 'empty'})` };
    const host = document.createElement('div');
    host.style.cssText = 'position:absolute;top:0;left:0;width:0;height:0;overflow:hidden;';
    const shadow = host.attachShadow({ mode: 'closed' });
    const wrap = document.createElement('div');
    wrap.style.cssText = 'all:initial;color:#000;display:block;';
    wrap.appendChild(document.importNode(root, true));
    shadow.appendChild(wrap);
    document.body.appendChild(host);
    const out = [];
    for (const el of wrap.querySelectorAll('*')) {
      if (el.closest('defs, mask, clipPath, symbol, pattern, marker') && el.localName !== 'stop') continue;
      for (const p of paintsOf(el, 'default')) out.push({ ...img, path: `${img.path} (SVG file: <${el.localName}>)`, ...p });
    }
    host.remove();
    return { paints: out.map((p) => ({ ...p, rgba: p.rgba && p.prop !== 'stop-color' ? [p.rgba[0], p.rgba[1], p.rgba[2], p.rgba[3] * img.opacity] : p.rgba })) };
  };

  const focusableCount = () => document.querySelectorAll('a[href], button, input, select, textarea, summary, iframe, [tabindex], [contenteditable]').length;

  window.__chk = { settle, stabilise, collectPaints, focusPaints, svgImagePaints, focusableCount, sections, landmarkInventory, copyTexts, images, overflow, hideOwnText, restoreText, prepareForShot, where, pathOf };
}
