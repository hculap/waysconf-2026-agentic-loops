// Decodes the .fig in design/ into design/data/*.json and design/images/*.
// Run with: npm run design
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { unzipSync, inflateSync } from 'fflate';
import { decompress as zstd } from 'fzstd';
import { decodeBinarySchema, compileSchema } from 'kiwi-schema';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DESIGN = path.join(ROOT, 'design');
const DATA = path.join(DESIGN, 'data');
const IMAGES = path.join(DESIGN, 'images');

// ---------------------------------------------------------------- decoding

export function decode(figPath) {
  const zip = unzipSync(fs.readFileSync(figPath));
  const canvas = zip['canvas.fig'];
  if (!canvas) throw new Error('canvas.fig not found in ' + figPath);
  const magic = Buffer.from(canvas.subarray(0, 8)).toString('latin1');
  if (magic !== 'fig-kiwi') throw new Error('Not a fig-kiwi file: ' + magic);
  const view = new DataView(canvas.buffer, canvas.byteOffset, canvas.byteLength);
  const version = view.getUint32(8, true);
  const chunks = [];
  for (let o = 12; o < canvas.length; ) {
    const len = view.getUint32(o, true);
    o += 4;
    chunks.push(canvas.subarray(o, o + len));
    o += len;
  }
  const unpack = (c) =>
    c[0] === 0x28 && c[1] === 0xb5 && c[2] === 0x2f && c[3] === 0xfd ? zstd(c) : inflateSync(c);
  const schema = decodeBinarySchema(unpack(chunks[0]));
  const message = compileSchema(schema).decodeMessage(unpack(chunks[1]));
  const meta = zip['meta.json'] ? JSON.parse(Buffer.from(zip['meta.json']).toString('utf8')) : null;
  const images = {};
  for (const [name, bytes] of Object.entries(zip)) {
    if (name.startsWith('images/') && bytes.length) images[name.slice(7)] = bytes;
  }
  return { version, message, meta, images };
}

// ---------------------------------------------------------------- helpers

const gid = (g) => (g ? `${g.sessionID}:${g.localID}` : null);
const hex = (bytes) => Buffer.from(bytes).toString('hex');
const hexColour = ({ r, g, b, a }) =>
  '#' +
  [r, g, b, ...(a < 1 ? [a] : [])].map((c) => Math.round(c * 255).toString(16).padStart(2, '0')).join('');

function blobToPath(bytes) {
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const out = [];
  const argc = { 1: 2, 2: 2, 3: 4, 4: 6 };
  const letter = { 0: 'Z', 1: 'M', 2: 'L', 3: 'Q', 4: 'C' };
  for (let o = 0; o < bytes.length; ) {
    const cmd = bytes[o++];
    if (!(cmd in letter)) break;
    const nums = [];
    for (let i = 0; i < (argc[cmd] || 0); i++, o += 4) nums.push(v.getFloat32(o, true));
    out.push(letter[cmd] + nums.join(' '));
  }
  return out.join(' ');
}

function imageInfo(bytes) {
  const b = Buffer.from(bytes);
  if (b.readUInt32BE(0) === 0x89504e47) return { format: 'png', pixelWidth: b.readUInt32BE(16), pixelHeight: b.readUInt32BE(20) };
  if (b[0] === 0xff && b[1] === 0xd8) {
    for (let o = 2; o < b.length; ) {
      if (b[o] !== 0xff) { o++; continue; }
      const marker = b[o + 1];
      if (marker >= 0xc0 && marker <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(marker))
        return { format: 'jpg', pixelWidth: b.readUInt16BE(o + 7), pixelHeight: b.readUInt16BE(o + 5) };
      o += 2 + b.readUInt16BE(o + 2);
    }
    return { format: 'jpg' };
  }
  if (b.toString('latin1', 0, 4) === 'GIF8') return { format: 'gif', pixelWidth: b.readUInt16LE(6), pixelHeight: b.readUInt16LE(8) };
  if (b.toString('latin1', 8, 12) === 'WEBP') return { format: 'webp' };
  return { format: 'bin' };
}

// ---------------------------------------------------------------- model

function buildModel({ message }) {
  const all = message.nodeChanges;
  const blobs = message.blobs || [];
  const byId = new Map(all.map((n) => [gid(n.guid), n]));

  // Skip soft-deleted nodes, everything under them, variables of deleted collections, deleted styles.
  const aliveMemo = new Map();
  const alive = (n) => {
    const k = gid(n.guid);
    if (aliveMemo.has(k)) return aliveMemo.get(k);
    let ok = !n.isSoftDeleted && !n.isSoftDeletedStyle && n.phase !== 'REMOVED';
    const parent = n.parentIndex && byId.get(gid(n.parentIndex.guid));
    if (ok && n.parentIndex && !parent) ok = false;
    if (ok && parent) ok = alive(parent);
    if (ok && n.type === 'VARIABLE') {
      const set = byId.get(gid(n.variableSetID?.guid));
      ok = !!set && alive(set);
    }
    aliveMemo.set(k, ok);
    return ok;
  };
  const nodes = all.filter(alive);
  const node = (g) => {
    const n = byId.get(typeof g === 'string' ? g : gid(g));
    return n && alive(n) ? n : null;
  };
  const children = new Map();
  for (const n of nodes) {
    if (!n.parentIndex) continue;
    const p = gid(n.parentIndex.guid);
    if (!children.has(p)) children.set(p, []);
    children.get(p).push(n);
  }
  for (const list of children.values())
    list.sort((a, b) => (a.parentIndex.position < b.parentIndex.position ? -1 : a.parentIndex.position > b.parentIndex.position ? 1 : 0));
  const kids = (n) => children.get(gid(n.guid)) || [];
  const parentOf = (n) => (n.parentIndex ? node(n.parentIndex.guid) : null);

  // Variables
  const sets = new Map();
  for (const n of nodes.filter((n) => n.type === 'VARIABLE_SET'))
    sets.set(gid(n.guid), { id: gid(n.guid), name: n.name, modes: (n.variableSetModes || []).map((m) => ({ id: gid(m.id), name: m.name })) });
  const variables = new Map();
  for (const n of nodes.filter((n) => n.type === 'VARIABLE')) {
    variables.set(gid(n.guid), { id: gid(n.guid), node: n, name: n.name, set: sets.get(gid(n.variableSetID.guid)) });
  }
  const dataValue = (d) => {
    const v = d?.value || {};
    if (v.alias) return { alias: variables.get(gid(v.alias.guid))?.name ?? `missing:${gid(v.alias.guid)}` };
    if (v.colorValue) return v.colorValue;
    if ('floatValue' in v) return v.floatValue;
    if ('boolValue' in v) return v.boolValue;
    if ('textValue' in v) return v.textValue;
    if (v.textDataValue) return v.textDataValue.characters;
    return v;
  };
  const variableValues = (v) => {
    const out = {};
    for (const e of v.node.variableDataValues?.entries || []) {
      const mode = v.set.modes.find((m) => m.id === gid(e.modeID));
      out[mode ? mode.name : gid(e.modeID)] = dataValue(e.variableData);
    }
    return out;
  };
  const resolveVariable = (name, seen = new Set()) => {
    const v = [...variables.values()].find((x) => x.name === name);
    if (!v || seen.has(name)) return undefined;
    seen.add(name);
    const vals = variableValues(v);
    const first = Object.values(vals)[0];
    return first && typeof first === 'object' && 'alias' in first ? resolveVariable(first.alias, seen) : first;
  };

  // Text styles
  const styles = new Map(nodes.filter((n) => n.styleType === 'TEXT').map((n) => [gid(n.guid), n]));

  // Component property definitions: variant-level id -> set-level definition
  const propDefs = new Map();
  for (const n of nodes) for (const d of n.componentPropDefs || []) if (d.name) propDefs.set(gid(d.id), { ...d, owner: n });
  const toSetDef = (id) => {
    for (const n of nodes)
      for (const d of n.componentPropDefs || []) if (gid(d.id) === id && d.parentPropDefId) return gid(d.parentPropDefId);
    return id;
  };
  const setDefCache = new Map();
  const setDefId = (id) => (setDefCache.has(id) ? setDefCache.get(id) : (setDefCache.set(id, toSetDef(id)), setDefCache.get(id)));

  return { nodes, blobs, node, kids, parentOf, sets, variables, variableValues, resolveVariable, dataValue, styles, propDefs, setDefId };
}

// ---------------------------------------------------------------- serialisation

function makeSerializer(m, stats) {
  const paints = (list) =>
    (list || []).map((p) => {
      const out = { type: p.type, visible: p.visible, opacity: p.opacity, blendMode: p.blendMode };
      if (p.color) Object.assign(out, { color: p.color, hex: hexColour(p.color) });
      const alias = p.colorVar?.value?.alias;
      if (alias) out.variable = m.variables.get(gid(alias.guid))?.name ?? `missing:${gid(alias.guid)}`;
      if (p.stops) out.gradientStops = p.stops.map((s) => ({ position: s.position, color: s.color, hex: hexColour(s.color), variable: s.colorVar?.value?.alias ? m.variables.get(gid(s.colorVar.value.alias.guid))?.name : undefined }));
      if (p.transform && p.type !== 'SOLID') out.transform = p.transform;
      if (p.image?.hash) {
        Object.assign(out, {
          imageHash: hex(p.image.hash),
          scaleMode: p.imageScaleMode,
          originalImageWidth: p.originalImageWidth,
          originalImageHeight: p.originalImageHeight,
          altText: p.altText,
        });
      }
      return out;
    });

  const geometry = (list) =>
    (list || []).map((g) => ({ windingRule: g.windingRule, d: m.blobs[g.commandsBlob] ? blobToPath(m.blobs[g.commandsBlob].bytes) : null }));

  const notesOf = (n) => {
    const plugin = (n.pluginData || []).filter((p) => p.key === 'note').map((p) => p.value);
    if (plugin.length) return plugin;
    return (n.annotations || []).map((a) => a.label).filter(Boolean);
  };

  // parameterConsumptionMap: field -> binding, with instance overrides replacing or unbinding
  const bindingsOf = (raw, ov) => {
    const map = new Map();
    for (const e of raw.parameterConsumptionMap?.entries || []) map.set(e.variableField, e.variableData);
    for (const e of ov?.parameterConsumptionMap?.entries || []) {
      if (e.variableData) map.set(e.variableField, e.variableData);
      else map.set(e.variableField, null);
    }
    return map;
  };

  function serialize(raw, env) {
    const ov = env.overrides?.get(gid(raw.guid));
    const n = ov ? { ...raw, ...ov } : raw;
    const derived = env.derived?.get([...env.prefix, gid(raw.guid)].join('/'));
    const bindings = bindingsOf(raw, ov);
    const out = { id: gid(raw.guid), type: n.type, name: n.name };
    if (env.prefix.length) out.instancePath = [...env.prefix, gid(raw.guid)].join('/');

    const variablesUsed = {};
    let visible = n.visible;
    let characters = n.textData?.characters;
    for (const [field, data] of bindings) {
      if (!data) continue;
      const ref = data.value?.propRefValue?.defId;
      if (ref) {
        const defId = m.setDefId(gid(ref));
        const value = env.props?.has(defId) ? env.props.get(defId) : m.propDefs.get(defId)?.varValue;
        const def = m.propDefs.get(defId);
        (out.boundProperties ||= {})[field] = def?.name ?? defId;
        if (field === 'TEXT_DATA' && value) characters = value.value?.textDataValue?.characters;
        if (field === 'VISIBLE' && value) visible = value.value?.boolValue;
        continue;
      }
      const alias = data.value?.alias || data.value?.fontStyleValue?.asFloat?.value?.alias;
      if (alias) variablesUsed[field] = m.variables.get(gid(alias.guid))?.name ?? `missing:${gid(alias.guid)}`;
    }
    out.visible = visible;
    if (n.opacity !== undefined && n.opacity !== 1) out.opacity = n.opacity;

    const transform = derived?.transform || n.transform;
    const size = derived?.size || n.size;
    if (transform) {
      out.x = transform.m02;
      out.y = transform.m12;
      if (transform.m01 || transform.m10) out.transform = transform;
    }
    if (size) Object.assign(out, { width: size.x, height: size.y });
    if (n.minSize) out.minSize = n.minSize;
    if (n.maxSize) out.maxSize = n.maxSize;

    if (n.fillPaints?.length) out.fills = paints(n.fillPaints);
    if (n.strokePaints?.length) {
      out.strokes = paints(n.strokePaints);
      out.strokeWeight = n.strokeWeight;
      out.strokeAlign = n.strokeAlign;
      if (n.borderStrokeWeightsIndependent)
        out.borderWeights = { top: n.borderTopWeight, right: n.borderRightWeight, bottom: n.borderBottomWeight, left: n.borderLeftWeight };
      if (n.dashPattern?.length) out.dashPattern = n.dashPattern;
    }
    if (n.rectangleCornerRadiiIndependent)
      out.radii = { topLeft: n.rectangleTopLeftCornerRadius, topRight: n.rectangleTopRightCornerRadius, bottomRight: n.rectangleBottomRightCornerRadius, bottomLeft: n.rectangleBottomLeftCornerRadius };
    else if (n.cornerRadius !== undefined) out.cornerRadius = n.cornerRadius;

    if (n.stackMode && n.stackMode !== 'NONE') {
      out.layout = {
        mode: n.stackMode,
        spacing: n.stackSpacing,
        counterSpacing: n.stackCounterSpacing,
        wrap: n.stackWrap,
        // stackPaddingRight/Bottom fall back to the horizontal/vertical padding when absent
        padding: {
          top: n.stackVerticalPadding,
          right: n.stackPaddingRight ?? n.stackHorizontalPadding,
          bottom: n.stackPaddingBottom ?? n.stackVerticalPadding,
          left: n.stackHorizontalPadding,
        },
        primaryAlign: n.stackPrimaryAlignItems,
        counterAlign: n.stackCounterAlignItems,
        primarySizing: n.stackPrimarySizing,
        counterSizing: n.stackCounterSizing,
      };
    }
    if (n.stackChildPrimaryGrow) out.grow = n.stackChildPrimaryGrow;
    if (n.stackChildAlignSelf && n.stackChildAlignSelf !== 'AUTO') out.alignSelf = n.stackChildAlignSelf;
    if (n.stackPositioning === 'ABSOLUTE') out.positioning = n.stackPositioning;
    if (n.layoutGrids) out.layoutGrids = n.layoutGrids;

    if (n.type === 'TEXT') {
      const style = n.styleIdForText?.guid ? m.styles.get(gid(n.styleIdForText.guid)) : null;
      // A linked text style decides how the text renders; the layer's own values are kept beside it.
      const src = style || n;
      out.text = {
        characters,
        styleName: style?.name,
        fontFamily: src.fontName?.family,
        fontStyle: src.fontName?.style,
        fontSize: src.fontSize,
        lineHeight: src.lineHeight,
        letterSpacing: src.letterSpacing,
        textCase: src.textCase,
        textDecoration: src.textDecoration,
        textAlignHorizontal: n.textAlignHorizontal,
        textAlignVertical: n.textAlignVertical,
        textAutoResize: n.textAutoResize,
      };
      if (style)
        out.text.layerOwnValues = { fontFamily: n.fontName?.family, fontStyle: n.fontName?.style, fontSize: n.fontSize, lineHeight: n.lineHeight, letterSpacing: n.letterSpacing, textCase: n.textCase, textDecoration: n.textDecoration };
      const rendered = derived ? derived.derivedTextData?.glyphs?.[0]?.fontSize : n.derivedTextData?.glyphs?.[0]?.fontSize;
      if (rendered !== undefined) out.text.renderedFontSize = rendered;
      if (n.textData?.characters !== characters) out.text.componentDefault = n.textData?.characters;
      const ids = n.textData?.characterStyleIDs;
      const table = n.textData?.styleOverrideTable;
      if (ids?.length && table?.length && characters === n.textData.characters) {
        const chars = [...characters];
        const runs = [];
        chars.forEach((ch, i) => {
          const sid = ids[i] ?? 0;
          const last = runs.at(-1);
          if (last && last.styleID === sid) last.text += ch;
          else runs.push({ styleID: sid, start: i, text: ch });
        });
        out.text.runs = runs.map((r) => {
          const o = table.find((t) => t.styleID === r.styleID);
          if (!o) return { start: r.start, text: r.text };
          const runStyle = o.styleIdForText?.guid ? m.styles.get(gid(o.styleIdForText.guid)) : null;
          return { start: r.start, text: r.text, styleName: runStyle?.name, textDecoration: o.textDecoration, fontStyle: o.fontName?.style, fills: o.fillPaints ? paints(o.fillPaints) : undefined };
        });
      }
    }
    if (Object.keys(variablesUsed).length) out.variables = variablesUsed;
    if (['VECTOR', 'ELLIPSE', 'STAR', 'LINE', 'REGULAR_POLYGON', 'BOOLEAN_OPERATION'].includes(n.type)) {
      const fillGeometry = geometry(derived?.fillGeometry || n.fillGeometry);
      const strokeGeometry = geometry(derived?.strokeGeometry || n.strokeGeometry);
      out.geometry = { fill: fillGeometry, stroke: strokeGeometry };
    }
    const notes = notesOf(n);
    if (notes.length) out.notes = notes;
    const description = n.symbolDescription ?? n.description;
    if (description) out.description = description;

    let childEnv = env;
    let childSource = raw;
    if (n.type === 'INSTANCE') {
      const symbol = m.node(n.overriddenSymbolID || n.symbolData?.symbolID);
      if (!symbol) {
        out.component = { missing: gid(n.symbolData?.symbolID) };
        stats.missingSymbols.push(out.id);
      } else {
        const overrides = new Map();
        for (const o of raw.symbolData?.symbolOverrides || []) {
          const k = gid(o.guidPath.guids.at(-1));
          overrides.set(k, { ...(overrides.get(k) || {}), ...o });
        }
        const self = overrides.get(gid(symbol.guid));
        if (self) {
          const selfNotes = notesOf(self);
          if (selfNotes.length) out.notes = selfNotes;
        }
        const props = new Map();
        for (const a of [...(raw.componentPropAssignments || []), ...(ov?.componentPropAssignments || [])])
          props.set(m.setDefId(gid(a.defID)), a.varValue);
        let derivedMap = env.derived;
        let prefix = [...env.prefix, gid(raw.guid)];
        if (raw.derivedSymbolData && !env.derived) {
          derivedMap = new Map(raw.derivedSymbolData.map((d) => [d.guidPath.guids.map(gid).join('/'), d]));
          prefix = [];
        }
        const setNode = m.parentOf(symbol);
        const isSet = setNode?.isStateGroup;
        const properties = {};
        for (const d of (isSet ? setNode : symbol).componentPropDefs || []) {
          if (!d.name || d.type === 'VARIANT') continue;
          const v = props.has(gid(d.id)) ? props.get(gid(d.id)) : d.varValue;
          properties[d.name] = m.dataValue(v);
        }
        out.component = {
          set: isSet ? setNode.name : null,
          componentId: gid(symbol.guid),
          variantName: symbol.name,
          variant: isSet ? parseVariant(symbol.name) : undefined,
          properties,
        };
        if (symbol.description || symbol.symbolDescription) out.component.description = symbol.symbolDescription ?? symbol.description;
        childEnv = { overrides, props, derived: derivedMap, prefix };
        childSource = symbol;
        stats.instances++;
      }
    } else if (n.type === 'SYMBOL' && !env.props) {
      childEnv = { ...env, props: new Map() };
    }
    const list = m.kids(childSource).map((c) => serialize(c, childEnv));
    if (list.length) out.children = list;
    return out;
  }
  return (raw) => serialize(raw, { prefix: [] });
}

const parseVariant = (name) =>
  Object.fromEntries(
    name
      .split(',')
      .map((s) => s.split('='))
      .filter((p) => p.length === 2)
      .map(([k, v]) => [k.trim(), v.trim()]),
  );

function walk(tree, ctx, fn, parentHidden = false) {
  const hidden = parentHidden || tree.visible === false;
  const path = [...ctx.path, tree.name];
  let section = ctx.section;
  if (!section && ctx.width && /^section-/.test(tree.name)) section = tree.name;
  const here = { ...ctx, path, section, hidden, ancestors: [...(ctx.ancestors || []), tree] };
  fn(tree, here);
  for (const c of tree.children || []) walk(c, here, fn, hidden);
}

// ---------------------------------------------------------------- main

function main() {
  const figs = fs.readdirSync(DESIGN).filter((f) => f.endsWith('.fig'));
  if (figs.length !== 1) throw new Error(`Expected exactly one .fig in design/, found ${figs.length}`);
  const figPath = path.join(DESIGN, figs[0]);
  const decoded = decode(figPath);
  const m = buildModel(decoded);
  const stats = { instances: 0, missingSymbols: [] };
  const serialize = makeSerializer(m, stats);
  const source = { file: path.relative(ROOT, figPath), fileName: decoded.meta?.file_name, exportedAt: decoded.meta?.exported_at, version: decoded.version };

  const doc = m.nodes.find((n) => n.type === 'DOCUMENT');
  const pages = m.kids(doc).filter((p) => p.type === 'CANVAS');

  // Top-level frames of every page, serialised with instances resolved.
  const pageTrees = pages.map((p) => ({ page: p.name, internal: !!p.internalOnly, visible: p.visible, frames: m.kids(p).filter((f) => !['VARIABLE_SET', 'VARIABLE'].includes(f.type) && f.styleType !== 'TEXT').map(serialize) }));

  // Width frames: top-level frames whose children are section-* frames.
  const widthFrames = [];
  const otherFrames = [];
  for (const pt of pageTrees)
    for (const f of pt.frames) {
      if ((f.children || []).some((c) => /^section-/.test(c.name))) widthFrames.push({ page: pt.page, frame: f });
      else if (/^TURBINE \//.test(f.name)) otherFrames.push({ page: pt.page, frame: f });
    }
  widthFrames.sort((a, b) => b.frame.width - a.frame.width);
  const widths = widthFrames.map((w) => w.frame.width);

  // Context for every node of every page
  const visits = [];
  for (const pt of pageTrees)
    for (const f of pt.frames) {
      const wf = widthFrames.find((w) => w.frame === f);
      const of = otherFrames.find((w) => w.frame === f);
      walk(f, { page: pt.page, width: wf ? f.width : of ? f.width : null, frame: f.name, path: [pt.page], section: of ? f.name : null }, (node, ctx) => visits.push({ node, ctx }));
    }
  const where = (ctx) => ({ path: ctx.path.join(' > '), page: ctx.page, width: ctx.width ?? undefined, section: ctx.section ?? undefined, hidden: ctx.hidden || undefined });

  // ---- sections.json
  const sectionNames = [];
  const orderByWidth = {};
  for (const w of widthFrames) {
    const secs = w.frame.children.filter((c) => /^section-/.test(c.name)).sort((a, b) => a.y - b.y);
    orderByWidth[w.frame.width] = secs.map((s) => s.name);
    for (const s of secs) if (!sectionNames.includes(s.name)) sectionNames.push(s.name);
  }
  const sectionsJson = {
    source,
    widths,
    frames: widthFrames.map((w) => ({ width: w.frame.width, page: w.page, frame: w.frame.name, height: w.frame.height })),
    orderByWidth,
    orderIsSameAtAllWidths: Object.values(orderByWidth).every((o) => o.join() === sectionNames.join()),
    sections: sectionNames.map((name, order) => ({
      name,
      order,
      byWidth: Object.fromEntries(
        widthFrames.map((w) => {
          const s = w.frame.children.find((c) => c.name === name);
          return [w.frame.width, s ? { y: s.y, height: s.height, node: s } : null];
        }),
      ),
    })),
    otherFrames: otherFrames.map((o) => ({ page: o.page, name: o.frame.name, width: o.frame.width, height: o.frame.height, node: o.frame })),
  };

  // ---- colours.json
  const colourVars = [...m.variables.values()].filter((v) => v.node.variableResolvedType === 'COLOR');
  const colourUse = new Map();
  const unbound = new Map();
  for (const { node, ctx } of visits) {
    for (const [prop, list] of [['fill', node.fills], ['stroke', node.strokes]])
      for (const p of list || []) {
        if (!p.color) continue;
        const use = { ...where(ctx), node: node.name, type: node.type, property: node.type === 'TEXT' && prop === 'fill' ? 'text' : prop, paintVisible: p.visible, opacity: p.opacity };
        if (p.variable) {
          if (!colourUse.has(p.variable)) colourUse.set(p.variable, []);
          colourUse.get(p.variable).push(use);
        } else {
          const k = JSON.stringify(p.color);
          if (!unbound.has(k)) unbound.set(k, { color: p.color, hex: p.hex, usedBy: [] });
          unbound.get(k).usedBy.push(use);
        }
      }
  }
  const coloursJson = {
    source,
    collections: [...m.sets.values()].map((s) => ({ name: s.name, modes: s.modes.map((x) => x.name) })),
    colours: colourVars.map((v) => {
      const values = m.variableValues(v);
      const resolved = m.resolveVariable(v.name);
      return {
        name: v.name,
        collection: v.set.name,
        values,
        hex: resolved && typeof resolved === 'object' && 'r' in resolved ? hexColour(resolved) : undefined,
        description: v.node.description,
        usedBy: colourUse.get(v.name) || [],
      };
    }),
    unknownVariables: [...colourUse.keys()].filter((k) => !colourVars.some((v) => v.name === k)).map((k) => ({ name: k, usedBy: colourUse.get(k) })),
    unboundColours: [...unbound.values()],
  };

  // ---- typography.json
  const styleUse = new Map();
  const unstyled = [];
  for (const { node, ctx } of visits) {
    if (node.type !== 'TEXT') continue;
    const t = node.text;
    const use = { ...where(ctx), node: node.name, characters: t.characters, layerOwnValues: t.layerOwnValues, renderedFontSize: t.renderedFontSize, runs: t.runs, variables: node.variables };
    if (t.styleName) {
      if (!styleUse.has(t.styleName)) styleUse.set(t.styleName, []);
      styleUse.get(t.styleName).push(use);
    } else unstyled.push({ ...use, fontFamily: t.fontFamily, fontStyle: t.fontStyle, fontSize: t.fontSize, lineHeight: t.lineHeight, letterSpacing: t.letterSpacing, textCase: t.textCase });
    for (const r of t.runs || []) if (r.styleName && r.styleName !== t.styleName) {
      if (!styleUse.has(r.styleName)) styleUse.set(r.styleName, []);
      styleUse.get(r.styleName).push({ ...use, run: r });
    }
  }
  const bindingNames = (n) => {
    const out = {};
    for (const e of n.parameterConsumptionMap?.entries || []) {
      const alias = e.variableData?.value?.alias || e.variableData?.value?.fontStyleValue?.asFloat?.value?.alias;
      if (alias) out[e.variableField] = m.variables.get(gid(alias.guid))?.name ?? `missing:${gid(alias.guid)}`;
    }
    return out;
  };
  const typographyJson = {
    source,
    styles: [...m.styles.values()].map((s) => ({
      name: s.name,
      id: gid(s.guid),
      description: s.styleDescription ?? s.description,
      fontFamily: s.fontName?.family,
      fontStyle: s.fontName?.style,
      fontPostscript: s.fontName?.postscript,
      fontSize: s.fontSize,
      lineHeight: s.lineHeight,
      letterSpacing: s.letterSpacing,
      textCase: s.textCase,
      textDecoration: s.textDecoration,
      variables: bindingNames(s),
      usedBy: styleUse.get(s.name) || [],
    })),
    variables: [...m.variables.values()].filter((v) => v.set.name.includes('Type') || /^responsive\/type\//.test(v.name)).map((v) => ({ name: v.name, collection: v.set.name, type: v.node.variableResolvedType, values: m.variableValues(v), description: v.node.description })),
    unstyledText: unstyled,
  };

  // ---- layout.json
  const layoutJson = {
    source,
    widths: widthFrames.map((w) => ({ width: w.frame.width, height: w.frame.height, page: w.page, frame: w.frame.name, layoutGrids: w.frame.layoutGrids, variableModes: modeNames(m, w.page) })),
    variables: [...m.sets.values()].filter((s) => !s.name.includes('Color')).map((s) => ({
      collection: s.name,
      modes: s.modes.map((x) => x.name),
      variables: [...m.variables.values()].filter((v) => v.set === s && v.node.variableResolvedType !== 'STRING').map((v) => ({ name: v.name, type: v.node.variableResolvedType, values: m.variableValues(v), description: v.node.description })),
    })),
    sections: sectionNames.map((name) => ({
      name,
      byWidth: Object.fromEntries(
        widthFrames.map((w) => {
          const list = [];
          const s = w.frame.children.find((c) => c.name === name);
          if (s)
            walk(s, { path: [], width: w.frame.width }, (node, ctx) => {
              if (!['FRAME', 'INSTANCE', 'SYMBOL', 'ROUNDED_RECTANGLE', 'RECTANGLE', 'ELLIPSE'].includes(node.type)) return;
              const kidsVisible = (node.children || []).filter((c) => c.visible !== false && c.positioning !== 'ABSOLUTE');
              const firstRowY = kidsVisible[0]?.y;
              const entry = {
                path: ctx.path.join(' > '),
                type: node.type,
                x: node.x,
                y: node.y,
                width: node.width,
                height: node.height,
                hidden: ctx.hidden || undefined,
                minSize: node.minSize,
                maxSize: node.maxSize,
                layout: node.layout,
                grow: node.grow,
                alignSelf: node.alignSelf,
                cornerRadius: node.cornerRadius,
                radii: node.radii,
                strokeWeight: node.strokes ? node.strokeWeight : undefined,
                borderWeights: node.borderWeights,
                variables: node.variables,
                columns: kidsVisible.length > 1 ? kidsVisible.filter((c) => c.y === firstRowY).length : undefined,
                component: node.component ? `${node.component.set ?? ''} ${node.component.variantName}`.trim() : undefined,
              };
              list.push(entry);
            });
          return [w.frame.width, list];
        }),
      ),
    })),
  };

  // ---- components.json
  const instancesBySymbol = new Map();
  for (const { node, ctx } of visits) {
    if (!node.component?.componentId) continue;
    const k = node.component.componentId;
    if (!instancesBySymbol.has(k)) instancesBySymbol.set(k, []);
    instancesBySymbol.get(k).push({ ...where(ctx), name: node.name, variant: node.component.variant, properties: node.component.properties, notes: node.notes });
  }
  const serializedById = new Map(visits.filter((v) => v.node.type === 'SYMBOL' || v.node.isStateGroup !== undefined).map((v) => [v.node.id, v]));
  for (const { node, ctx } of visits) if (!serializedById.has(node.id)) serializedById.set(node.id, { node, ctx });
  const componentsJson = {
    source,
    components: m.nodes.filter((n) => n.isStateGroup).map((set) => {
      const variants = m.kids(set).filter((v) => v.type === 'SYMBOL');
      const sv = serializedById.get(gid(set.guid));
      return {
        set: set.name,
        id: gid(set.guid),
        path: sv ? sv.ctx.path.join(' > ') : undefined,
        description: set.symbolDescription ?? set.description,
        properties: (set.componentPropDefs || []).filter((d) => d.type !== 'VARIANT').map((d) => ({ name: d.name, type: d.type, default: m.dataValue(d.varValue) })),
        axes: (set.stateGroupPropertyValueOrders || []).map((a) => ({ property: a.property, values: a.values })),
        variants: variants.map((v) => {
          const s = serializedById.get(gid(v.guid));
          return { name: v.name, variant: parseVariant(v.name), id: gid(v.guid), width: v.size?.x, height: v.size?.y, description: v.symbolDescription ?? v.description, notes: s?.node.notes, node: s?.node, instances: instancesBySymbol.get(gid(v.guid)) || [] };
        }),
      };
    }),
    standalone: m.nodes
      .filter((n) => n.type === 'SYMBOL' && !m.parentOf(n)?.isStateGroup)
      .map((v) => {
        const s = serializedById.get(gid(v.guid));
        return { name: v.name, id: gid(v.guid), path: s?.ctx.path.join(' > '), description: v.symbolDescription ?? v.description, properties: (v.componentPropDefs || []).filter((d) => d.name && d.type !== 'VARIANT').map((d) => ({ name: d.name, type: d.type, default: m.dataValue(d.varValue) })), width: v.size?.x, height: v.size?.y, notes: s?.node.notes, node: s?.node, instances: instancesBySymbol.get(gid(v.guid)) || [] };
      }),
  };

  // ---- copy.json
  const copyEntries = (filter) => {
    const entries = [];
    const index = new Map();
    const seen = new Map();
    const add = (kind, text, node, ctx, keyPath) => {
      if (text === undefined || text === null || text === '') return;
      // the same text repeated at the same place counts once per occurrence, per width
      const base = `${kind}|${keyPath}|${text}`;
      const occ = `${ctx.width ?? ctx.frame}|${base}`;
      const nth = (seen.get(occ) || 0) + 1;
      seen.set(occ, nth);
      const key = `${base}#${nth}`;
      if (index.has(key)) {
        const e = index.get(key);
        if (ctx.width && !e.widths.includes(ctx.width)) e.widths.push(ctx.width);
        if (!ctx.hidden) e.hiddenAt = e.hiddenAt.filter(() => true);
        if (ctx.hidden && ctx.width) e.hiddenAt.push(ctx.width);
        return;
      }
      const e = { kind, text, node: node.name, key: keyPath, widths: ctx.width ? [ctx.width] : [], hiddenAt: ctx.hidden && ctx.width ? [ctx.width] : [], path: ctx.path.join(' > ') };
      if (ctx.hidden && !ctx.width) e.hidden = true;
      if (node.text?.styleName) e.style = node.text.styleName;
      if (node.component?.properties) e.component = `${node.component.set ?? node.component.variantName}`;
      index.set(key, e);
      entries.push(e);
    };
    for (const { node, ctx } of visits.filter(filter)) {
      const keyPath = ctx.path.slice(ctx.section ? ctx.path.indexOf(ctx.section) : 1).join(' > ');
      if (node.type === 'TEXT') add('text', node.text.characters, node, ctx, keyPath);
      for (const note of node.notes || []) add('note', note, node, ctx, keyPath);
      for (const p of node.fills || []) if (p.imageHash && p.altText) add('alt', p.altText, node, ctx, keyPath);
    }
    for (const e of entries) if (!e.hiddenAt.length) delete e.hiddenAt;
    return entries;
  };
  const copyJson = {
    source,
    sections: sectionNames.map((name) => ({ name, entries: copyEntries((v) => v.ctx.section === name && widthFrames.some((w) => w.frame.width === v.ctx.width && w.frame.name === v.ctx.frame)) })),
    otherFrames: otherFrames.map((o) => ({ name: o.frame.name, entries: copyEntries((v) => v.ctx.frame === o.frame.name) })),
    otherPages: pageTrees
      .filter((pt) => !widthFrames.some((w) => w.page === pt.page) || pt.frames.some((f) => !widthFrames.some((w) => w.frame === f) && !otherFrames.some((o) => o.frame === f)))
      .map((pt) => ({
        page: pt.page,
        frames: pt.frames.filter((f) => !widthFrames.some((w) => w.frame === f) && !otherFrames.some((o) => o.frame === f)).map((f) => ({ name: f.name, entries: copyEntries((v) => v.ctx.page === pt.page && v.ctx.frame === f.name && v.ctx.path[1] === f.name) })),
      }))
      .filter((p) => p.frames.length),
    textStyleSamples: [...m.styles.values()].map((s) => ({ style: s.name, text: s.textData?.characters })),
  };

  // ---- images.json + files
  fs.rmSync(DATA, { recursive: true, force: true });
  fs.rmSync(IMAGES, { recursive: true, force: true });
  fs.mkdirSync(DATA, { recursive: true });
  fs.mkdirSync(path.join(IMAGES, 'icons'), { recursive: true });

  const imageUse = new Map();
  for (const { node, ctx } of visits)
    for (const p of node.fills || []) {
      if (!p.imageHash) continue;
      if (!imageUse.has(p.imageHash)) imageUse.set(p.imageHash, []);
      // the note describing the image sits on the image node or on the nearest ancestor that has one
      const note = [...ctx.ancestors].reverse().flatMap((a) => a.notes || []).find((t) => /Image fill:|alt="/.test(t));
      const assetFrame = [...ctx.ancestors].reverse().find((a) => /^asset\//.test(a.name));
      const assetTexts = [];
      if (assetFrame) walk(assetFrame, { path: [] }, (n) => n.type === 'TEXT' && assetTexts.push(n.text.characters));
      imageUse.get(p.imageHash).push({ ...where(ctx), node: node.name, frameWidth: node.width, frameHeight: node.height, scaleMode: p.scaleMode, paintVisible: p.visible, opacity: p.opacity, originalImageWidth: p.originalImageWidth, originalImageHeight: p.originalImageHeight, altText: p.altText, note, assetFrame: assetFrame?.name, assetFrameTexts: assetFrame ? assetTexts : undefined });
    }
  const images = [];
  for (const [hash, usedBy] of imageUse) {
    const bytes = decoded.images[hash];
    if (!bytes) {
      images.push({ hash, file: null, missingFromFile: true, usedBy });
      continue;
    }
    const info = imageInfo(bytes);
    const file = `design/images/${hash}.${info.format}`;
    fs.writeFileSync(path.join(ROOT, file), bytes);
    const found = (re) => [...new Set(usedBy.map((u) => u.note?.match(re)?.[1]).filter((x) => x !== undefined))];
    images.push({
      hash,
      file,
      ...info,
      bytes: bytes.length,
      exportNames: found(/Image fill:\s*(\S+?\.(?:jpe?g|png|webp|gif|svg))/i),
      alt: found(/alt="([^"]*)"/),
      assetFrames: [...new Set(usedBy.map((u) => u.assetFrame).filter(Boolean))],
      assetFrameTexts: usedBy.find((u) => u.assetFrameTexts)?.assetFrameTexts,
      altTextFields: [...new Set(usedBy.map((u) => u.altText).filter(Boolean))],
      usedBy,
    });
  }
  const unused = Object.keys(decoded.images)
    .filter((h) => !imageUse.has(h))
    .map((h) => ({ hash: h, bytes: decoded.images[h].length, ...imageInfo(decoded.images[h]) }));

  // Icons: each icon layer (named icon, favicon, tick, chevron…) with all its vector parts, written as one SVG.
  const ICON = /(^|\/)(icon|favicon|tick|chevron|error-icon)(\/|$)/i;
  const hasText = (n) => n.type === 'TEXT' || (n.children || []).some(hasText);
  const hasGeometry = (n) => !!n.geometry || (n.children || []).some(hasGeometry);
  const isIcon = (n) => ICON.test(n.name) && !hasText(n) && hasGeometry(n);
  const icons = new Map();
  const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  for (const { node, ctx } of visits) {
    if (!isIcon(node) || ctx.ancestors.slice(0, -1).some(isIcon)) continue;
    const parts = [];
    const collect = (n, m, root) => {
      if (n.visible === false && !root) return;
      const own = root ? [1, 0, 0, 1, 0, 0] : n.transform ? [n.transform.m00, n.transform.m10, n.transform.m01, n.transform.m11, n.transform.m02, n.transform.m12] : [1, 0, 0, 1, n.x ?? 0, n.y ?? 0];
      const mat = [m[0] * own[0] + m[2] * own[1], m[1] * own[0] + m[3] * own[1], m[0] * own[2] + m[2] * own[3], m[1] * own[2] + m[3] * own[3], m[0] * own[4] + m[2] * own[5] + m[4], m[1] * own[4] + m[3] * own[5] + m[5]];
      if (n.geometry) {
        const paint = (list) => (list || []).find((p) => p.visible !== false && p.color);
        for (const g of n.geometry.fill) if (g.d) parts.push({ d: g.d, rule: g.windingRule, paint: paint(n.fills), mat, opacity: n.opacity });
        for (const g of n.geometry.stroke) if (g.d) parts.push({ d: g.d, rule: g.windingRule, paint: paint(n.strokes), mat, opacity: n.opacity });
      }
      for (const c of n.children || []) collect(c, mat, false);
    };
    collect(node, [1, 0, 0, 1, 0, 0], true);
    if (!parts.length) continue;
    const body = parts
      .map((p) => {
        const alpha = p.paint ? p.paint.color.a * (p.paint.opacity ?? 1) * (p.opacity ?? 1) : 1;
        const t = p.mat.join(',') === '1,0,0,1,0,0' ? '' : ` transform="matrix(${p.mat.join(' ')})"`;
        return `<path d="${p.d}"${t} fill="${p.paint ? p.paint.hex.slice(0, 7) : 'currentColor'}"${alpha !== 1 ? ` fill-opacity="${alpha}"` : ''}${p.rule === 'ODD' ? ' fill-rule="evenodd"' : ''}/>`;
      })
      .join('');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${node.width}" height="${node.height}" viewBox="0 0 ${node.width} ${node.height}" fill="none">${body}</svg>\n`;
    if (!icons.has(svg)) icons.set(svg, { name: node.name, svg, width: node.width, height: node.height, colours: [...new Set(parts.map((p) => p.paint?.variable ?? p.paint?.hex))], usedBy: [] });
    icons.get(svg).usedBy.push({ ...where(ctx), node: node.name });
  }
  const byName = new Map();
  for (const ic of icons.values()) byName.set(ic.name, [...(byName.get(ic.name) || []), ic]);
  const iconList = [];
  for (const [name, list] of byName)
    list.forEach((ic, i) => {
      const variant = list.length > 1 ? '--' + slug(ic.colours.join('-')) : '';
      let file = `design/images/icons/${slug(name)}${variant}.svg`;
      if (iconList.some((x) => x.file === file)) file = file.replace(/\.svg$/, `-${i + 1}.svg`);
      fs.writeFileSync(path.join(ROOT, file), ic.svg);
      iconList.push({ file, name, width: ic.width, height: ic.height, colours: ic.colours, usedBy: ic.usedBy });
    });

  const imagesJson = { source, images, unused, icons: iconList };

  const write = (name, obj) => fs.writeFileSync(path.join(DATA, name), JSON.stringify(obj, null, 2) + '\n');
  write('sections.json', sectionsJson);
  write('colours.json', coloursJson);
  write('typography.json', typographyJson);
  write('layout.json', layoutJson);
  write('components.json', componentsJson);
  write('copy.json', copyJson);
  write('images.json', imagesJson);

  console.log(
    `Decoded ${source.file} (fig-kiwi v${decoded.version}): ${m.nodes.length} nodes, ${stats.instances} instances resolved, ` +
      `${sectionNames.length} sections at widths ${widths.join('/')}, ${images.length} images (+${unused.length} unused), ${iconList.length} icons.`,
  );
  if (stats.missingSymbols.length) console.warn(`Instances with missing components: ${stats.missingSymbols.join(', ')}`);
}

function modeNames(m, pageName) {
  const doc = m.nodes.find((n) => n.type === 'DOCUMENT');
  const page = m.kids(doc).find((p) => p.name === pageName);
  const frame = page && m.kids(page).find((f) => f.variableModeBySetMap);
  if (!frame) return {};
  const out = {};
  for (const e of frame.variableModeBySetMap.entries) {
    const set = m.sets.get(gid(e.variableSetID.guid));
    out[set?.name ?? gid(e.variableSetID.guid)] = set?.modes.find((x) => x.id === gid(e.variableModeID))?.name ?? gid(e.variableModeID);
  }
  return out;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) main();
