# Rescue pack: design-data

Made from a complete run of the workshop prompts. It replaces the step before prompt 03.

## For the agent

1. Copy every file in this pack into the project, keeping the folders. Replace files with the same path.
2. Add these scripts to package.json (keep the ones already there):
- `design`: `node scripts/design.mjs`
3. Install:
   no runtime dependencies
   `npm install --save-dev fflate@^0.8.3 fzstd@^0.1.1 kiwi-schema@^0.5.0`

Then commit with the message "Rescue pack: design-data" and push. Tell the person to type /clear and paste prompt 03.

## Files

- design/data/colours.json
- design/data/components.json
- design/data/copy.json
- design/data/images.json
- design/data/layout.json
- design/data/sections.json
- design/data/typography.json
- design/images/08f16827c8b03b8e7899003845b1210433f849fd.jpg
- design/images/2e2645f11562174c16e1fa35916997fc68febd54.jpg
- design/images/3a45be18f3edc59f91e78ccb734afa32ccaea0e1.jpg
- design/images/3e8bc9478563a4f238302aff85dd77600a261917.jpg
- design/images/664ff24a367f770c3bc29e4407dd2ea14304d146.jpg
- design/images/6ae5871c33bde60c733b21c438a02085cbc8f31d.jpg
- design/images/874d65de73bfbe5535e78bf3d72c9c16da6aa1ed.jpg
- design/images/a13d346062f0a7bc91d3691d4c8eaf4a2f51a0ac.jpg
- design/images/b496b56c2f11b719a56eb34232d142661e912770.jpg
- design/images/c90ae1ffc7447933aa7f24ded70abb87f341d73e.jpg
- design/images/d559cd8f40156b540ea79560cd8bfe500b310467.jpg
- design/images/d788fe6daf6222dfa5e26b9e68bf160801bab877.jpg
- design/images/d82e25d2fdef288d9512d5b7d2e4ea3d71cf8997.jpg
- design/images/ecba1283f9f868ba28b0a5264d6c85e49f6c047f.jpg
- design/images/f1a67849d21d65ab3e6c8c75840e11385912c0ed.jpg
- design/images/icons/button-icon--color-accent-coolant.svg
- design/images/icons/button-icon--color-bg-base.svg
- design/images/icons/button-icon--color-text-primary.svg
- design/images/icons/button-icon--color-text-secondary.svg
- design/images/icons/faq-chevron.svg
- design/images/icons/favicon.svg
- design/images/icons/icon-bandcamp.svg
- design/images/icons/icon-chevron.svg
- design/images/icons/icon-info.svg
- design/images/icons/icon-instagram.svg
- design/images/icons/icon-mastodon.svg
- design/images/icons/icon-menu.svg
- design/images/icons/input-error-icon.svg
- design/images/icons/input-tick.svg
- scripts/design.mjs
